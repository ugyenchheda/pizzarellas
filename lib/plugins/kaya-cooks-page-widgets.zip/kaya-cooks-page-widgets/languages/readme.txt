Official info about translation: http://codex.wordpress.org/Translating_WordPress



Open kaya-cooks-page-widgets-en_US.po file and save new copy as kaya-cooks-page-widgets-es_ES.po for Spanish.And then use translating program to translate it to Spanish language.