<?php
/*  
    Plugin Name: Kaya Cooks Page Widget
    Plugin URI: http://themeforest.net/user/kayapati/portfolio
    Description: The easy way to create page layouts using Widgets in Pages or post with the help of Widget based page builder like   "SiteOrigin" Page Builder, always note these works better in pages only, 
                 not rcomended for sidebars. 
    Author: Ram
    Author URI: http://themeforest.net/user/kayapati/portfolio
    Version: 1.7.4
*/  
// Portfolio
define('cooks',  'kaya-cooks-page-widgets');
 class cooks_Portfolio_Widget extends WP_Widget{
    public function __construct(){
        parent::__construct('kaya-portfolio-widget',
            __('Cooks-Food Menu (PB)',cooks),
            array('description' => __('Displays all portfolio items in grid style',cooks), 'class' => 'portfolio_widget')
        );
    }

    public function widget( $args, $instance ) {
      echo $args['before_widget'];  
          global $post;
      $instance=wp_parse_args($instance, array(
         
          'title' => __('Food Menu Title',cooks),
          'description' => '',
          'columns' => '4',
          'readmore_text' => __('Read More',cooks),
          'text_align'   => __('left',cooks),
          'title_color' => '#343434',
          'pf_img_height' => '400',
          'portfolio_limit' => '',
          'kaya_portfolio_filter' => __('false',cooks),
          'portfolio_widget_category' => '',
          'disable_title' => '',
          'Popular_post_display' => '',
          'pf_display_orderby' => __('date',cooks),
          'pf_display_order' => __('DESC',cooks),
          'fluid_pf_gallery' => '',
          'hide_post_link_icon' => '',
          'hide_lightbox_icon' => '',
          'hide_post_title' => '',
          'post_title_bg_color' => '',
          'post_title_color' => '#333',
          'hide_price' => '',
          'filter_tab_bg_color' => '#333',
          'filter_tab_text_color' => '#ffffff',
          'filter_tab_active_bg_color' => '#ff6c00',
          'filter_tab_active_text_color' => '#ffffff',
          'disable_pagination' => '',
      )); ?>
<?php   $effects = rand(1,200);
        $rand = rand(1,200);
        $post_icon = ( $instance['hide_lightbox_icon'] == 'on' ) ? "50%" : '30%'; ?>
        <?php $post_class = ( $instance['hide_lightbox_icon'] == 'on' ) ? "left" : 'right'; ?>
        <?php $lightbox_icon = ( $instance['hide_post_link_icon'] == 'on' ) ? "50%" : '30%'; ?>
    <?php  switch( $instance['columns'] ){
         case 5:
            $width = "480";
            $height = $instance['pf_img_height'] ? $instance['pf_img_height'] : '400';
            break;
        case 4:
            $width = "500";
            $height = $instance['pf_img_height'] ? $instance['pf_img_height'] : '400';
            break;
        case 3:
            $width =  ( $instance['fluid_pf_gallery'] == '1' ) ? '650' : '500';
            $height = $instance['pf_img_height'] ? $instance['pf_img_height'] : '400';
            break;
         case 2:
             $width =  ( $instance['fluid_pf_gallery'] == '1' ) ? '920' : '630';
            $height = $instance['pf_img_height'] ? $instance['pf_img_height'] : '400';
      } 

      if( $instance['fluid_pf_gallery'] == 'on'){
       $rand = rand(1,100);
        $fluid_gallery = 'id=portfolio_fluid'.$rand;
        $fluid_gallery_width = 'portfolio_fluid';
      ?>
       
    <script>
      (function( $ ) {
       "use strict";
       $(function() {
         function portfolio_gallery_fluid(){
           var $content_width= $('#portfolio_fluid<?php echo $rand; ?>').width($(window).width());
           var $container_fluid = Math.ceil( (( ($(window).width() - 5)  - parseInt($('.container').css('width'))) / 2) );
           $('#portfolio_fluid<?php echo $rand; ?>').css({
             'margin-left' : -$container_fluid,
             width : $content_width+'25'
             });
        }
         portfolio_gallery_fluid();
         $(window).resize(function(){
           portfolio_gallery_fluid();
        });   
      });
      })(jQuery);
      </script>
    <?php  }else{
      $fluid_gallery = '';
      $fluid_gallery_width = '';
    }
    ?>
    <script type="text/javascript">
      (function($) {
        "use strict";
        $(function() {
            // Hover Effects
        $('.widget_kaya-portfolio-widget .Portfolio_gallery-<?php echo $effects; ?> li').hover(function(){
          $(this).find('img').fadeTo(500,0.6);
          $(this).find('.link_to_image, .link_to_video').css({'left':'-100px','display':'block'}).stop().animate({'left':'<?php echo $lightbox_icon; ?>', opacity:1},600);
          $(this).find('.link_to_post').css({'<?php echo $post_class; ?>':'-100px','display':'block'}).stop().animate({'<?php echo $post_class; ?>':'<?php echo $post_icon; ?>',opacity:1},600);
          //alert('test');
        },function(){
          $(this).find('img').fadeTo(500,1);
          $(this).find('.link_to_image, .link_to_video').css({'left':'100','display':'block'}).stop().animate({'left':'-<?php echo $lightbox_icon; ?>',opacity:0},600);
          $(this).find('.link_to_post').css({'<?php echo $post_class; ?>':'100px','display':'block'}).stop().animate({'<?php echo $post_class; ?>':'-<?php echo $post_icon; ?>',opacity:0},600);
       }); 

         });

      })(jQuery);
     </script>
     </script>
          <style type="text/css">
      #mid_container_wrapper .widget_kaya-portfolio-widget .filter-<?php echo $rand; ?> a:hover, .filter-<?php echo $rand; ?> .active{
        background-color: <?php echo $instance['filter_tab_active_bg_color']; ?>!important;
        color: <?php echo $instance['filter_tab_active_text_color']; ?>!important;
      }
     </style>
    <?php 
        // $title = apply_filters('widget_title' ,$title);
     $array_val = ( !empty( $instance['portfolio_widget_category'] )) ? explode(',',  $instance['portfolio_widget_category']) : '';
         if( $instance['title'] ):
            echo '<div class="portfolio_title custom_title kaya_title_'.$instance['text_align'].'">';
             echo  '<h3 style="text-align:'.$instance['text_align'].'; color:'.$instance['title_color'].'!important;">'.$instance['title'].'</h3>';
             echo '</div>';
             ?>
            <div class="clear"> </div>
            <?php endif; 
               if ($instance['kaya_portfolio_filter'] == 'true'){ // open filter settings
            echo '<div class="filter_portfolio">';
              echo '<div class="filter filter-'.$rand.'" id="filter">';
                echo '<ul style="text-align:'.$instance['text_align'].';">';
                  echo '<li class="all" ><a class="" href="#" style="color:'.$instance['filter_tab_text_color'].'; background:'.$instance['filter_tab_bg_color'].';" data-category="all">'.__( 'All', cooks ).'</a></li>';
                  $category = trim( $instance['portfolio_widget_category']);
                  if( $category ){
                    $pf_categories = @explode(',', $category);
                     for($i=0;$i<count($pf_categories);$i++){
                      $terms[] = get_term_by('id', $pf_categories[$i], 'portfolio_category');
                    } } else {
                      $terms = get_terms('portfolio_category');
                    }
                    foreach($terms as $term) {
                    echo '<li  class="cat-'.$term->term_id .'" >';
                    echo '<a href="" style="color:'.$instance['filter_tab_text_color'].'; background:'.$instance['filter_tab_bg_color'].';" data-category="cat-' . $term->term_id . '">' . $term->name . ' </a></li>';
                    }
                    //print_r($terms);
                echo '</ul>';
             echo '</div>';
           echo '</div>'; 
      } // end filter ?>
    <div class="Portfolio_gallery cooks_portfolio_gallery Portfolio_gallery-<?php echo $effects; ?> <?php echo $fluid_gallery_width; ?>" <?php echo $fluid_gallery; ?>>
      <ul  id="list"  class="isotope-container portfolio<?php echo $instance['columns'] ?> porfolio_items portfolio_extra clearfix">
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; 
   if( $instance["Popular_post_display"] == '1' || $instance["Popular_post_display"] == 'on' ){
           $args = array('paged' => $paged, 'post_type' => 'portfolio', 'showposts' => $instance['portfolio_limit'], 'meta_key' => 'post_views_count', 'orderby' => 'meta_value_num', 'field' => 'id', 'order' => $instance['pf_display_order'], 'taxonomy' => 'portfolio_category');
        }else{
         if( $array_val ) {
          $args = array( 'paged' => $paged, 'post_type' => 'portfolio',  'orderby' => $instance['pf_display_orderby'], 'posts_per_page' =>$instance['portfolio_limit'],'order' => $instance['pf_display_order'],  'tax_query' => array('relation' => 'AND', array( 'taxonomy' => 'portfolio_category',   'field' => 'id', 'terms' => $array_val  ), ));
          }else{
             $args = array( 'paged' => $paged, 'post_type' => 'portfolio', 'taxonomy' => 'portfolio_category','term' => $instance['portfolio_widget_category'], 'orderby' => $instance['pf_display_orderby'], 'posts_per_page' =>$instance['portfolio_limit'],'order' => $instance['pf_display_order']);
          }
        }
      query_posts($args);
      if( have_posts() ) : while( have_posts() ) : the_post();
      $terms = get_the_terms(get_the_ID(), 'portfolio_category');
      $pf_link_new_window=get_post_meta(get_the_ID(),'pf_link_new_window' ,true);
            if($pf_link_new_window == '1') { $pf_target_link ="_blank"; }else{ $pf_target_link ='_self'; }
            $permalink = get_permalink();
            $Porfolio_customlink=get_post_meta($post->ID,'Porfolio_customlink',true);
            $pf_customlink = $Porfolio_customlink ? $Porfolio_customlink : $permalink;
        $terms_id = array();
        $terms_name = array();
        if($terms ){
        foreach ($terms as $term) {
          $terms_id[] = 'cat-'.$term->term_id;
          $terms_name[] = $term ->name;
        }
      }else{
        $terms_name[] = 'Uncategorized';
      }
        echo '<li class="isotope-item all '.implode(' ', $terms_id).'">';   ?>
        <div class="item_container">
      <?php $img_url = wp_get_attachment_url( get_post_thumbnail_id() );
        global $post;
         $lightbox_url =  get_template_directory_uri().'/images/defult_featured_img.png';
         $featured_img = $img_url ? $img_url : $lightbox_url;
          $video_url= get_post_meta($post->ID,'video_url',true);
           $lightbox_type = $video_url ? trim($video_url) : $featured_img;
           $class = $video_url ? 'link_to_video' : 'link_to_image';
            if( $img_url ) {
                $lightbox_url =  $img_url;
              echo '<img src="'.aq_resize( $img_url, $width, $height, true ).'" alt="'.get_the_title().'" />';
              }else{
                 echo '<img src="'.get_template_directory_uri().'/images/defult_featured_img.png" alt="'.get_the_title().'" style="width:1100px; height:250px;">';
              } 
              $price = get_post_meta(get_the_ID(),'fooditem_price',true);
              if( $price &&  $instance['hide_price'] != 'on' ): echo '<span class="item_price">'.$price.'</span>'; endif; ?>
        <?php if( $instance['hide_lightbox_icon'] != '1' && $instance['hide_lightbox_icon'] != 'on' ): ?>
                <a class="<?php echo $class; ?> pf_images" rel="prettyPhoto['gallery']" title="<?php echo the_title();?>" href="<?php echo $lightbox_type; ?>" >&nbsp;</a>
        <?php endif; ?>
        <?php if( $instance['hide_post_link_icon'] != '1' && $instance['hide_post_link_icon'] != 'on' ): ?>
                <a class="link_to_post" target = "<?php echo $pf_target_link; ?>" href="<?php echo $pf_customlink; ?>">&nbsp; </a>
        <?php endif; ?>
       </div> 
                    <?php if( $instance['hide_post_title'] != 'on' ): ?>
             <div class="portfolio_post_content" style="background-color:<?php echo $instance['post_title_bg_color']; ?>">
                <?php echo '<h4 style="color:'.$instance['post_title_color'].';">'.get_the_title().'</h4>'; 
              echo '</div>';  
            endif; ?>
       </li>
       <?php endwhile; endif; ?>
    </ul> <?php
      if( $instance['disable_pagination'] != 'on'){
          echo kaya_pagination();    
       } 
      wp_reset_query(); ?>
    </div>
    <?php 

    }

    public function form($instance){

      $portfolio_terms=  get_terms('portfolio_category','');
          $portfolio_terms=  get_terms('portfolio_category','');
        if( $portfolio_terms ){
          foreach ($portfolio_terms as $portfolio_term) { 
            $pf_cat_ids[] = $portfolio_term->term_id;
             $pf_cats_name[] = $portfolio_term->name.' - '.$portfolio_term->term_id;
          }
        }else{ $pf_cats_name[] = ''; $pf_cat_ids[] =''; }

         $instance = wp_parse_args($instance, array(
          'title' => __('Food Menu Title',cooks),
          'description' => '',
          'columns' => '4',
          'readmore_text' => __('Read More',cooks),
          'text_align'   => __('left',cooks),
          'title_color' => '#343434',
          'pf_img_height' => '400',
          'portfolio_limit' => '',
          'kaya_portfolio_filter' => __('false',cooks),
          'portfolio_widget_category' => implode(',', $pf_cat_ids),
          'disable_title' => '',
          'Popular_post_display' => '',
          'pf_display_orderby' => __('date',cooks),
          'pf_display_order' => __('DESC',cooks),
          'fluid_pf_gallery' => '',
          'hide_post_link_icon' => '',
          'hide_lightbox_icon' => '',
          'hide_post_title' => '',
          'post_title_bg_color' => '',
          'post_title_color' => '#333',
          'hide_price' => '',
          'filter_tab_bg_color' => '#333',
          'filter_tab_text_color' => '#ffffff',
          'filter_tab_active_bg_color' => '#ff6c00',
          'filter_tab_active_text_color' => '#ffffff',
          'disable_pagination' => '',
      )); ?>

            <script type="text/javascript">
      (function($) {
        "use strict";
        $(function() {
        $("#<?php echo $this->get_field_id('kaya_portfolio_filter') ?>").change(function () {
        $("#<?php echo $this->get_field_id('filter_tab_bg_color'); ?>").parent().hide();
        $("#<?php echo $this->get_field_id('filter_tab_text_color'); ?>").parent().hide()
        $("#<?php echo $this->get_field_id('filter_tab_active_bg_color'); ?>").parent().hide()
        $("#<?php echo $this->get_field_id('filter_tab_active_text_color'); ?>").parent().hide()
        var selectlayout = $("#<?php echo $this->get_field_id('kaya_portfolio_filter') ?> option:selected").val(); 
        switch(selectlayout)
          {
            case 'true':
              $("#<?php echo $this->get_field_id('filter_tab_bg_color'); ?>").parent().show();
              $("#<?php echo $this->get_field_id('filter_tab_text_color'); ?>").parent().show()
              $("#<?php echo $this->get_field_id('filter_tab_active_bg_color'); ?>").parent().show()
              $("#<?php echo $this->get_field_id('filter_tab_active_text_color'); ?>").parent().show()
            break;      
          }
        }).change();


        });
      })(jQuery);
      </script>
<p>
  <lable for="<?php echo $this->get_field_id('title'); ?>">
  <?php _e('Title',cooks); ?>
  </label>
  <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo $this->get_field_name('title') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('title_color'); ?>">
  <?php _e('Title Color',cooks) ?>
  </label>
  <input type="text" name="<?php echo $this->get_field_name('title_color') ?>" id="<?php echo $this->get_field_id('title_color') ?>" class="widefat" value="<?php echo $instance['title_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('text_align') ?>">
  <?php _e('Title / Filters Tabs Position',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('text_align') ?>">
    <option value="left" <?php selected('left', $instance['text_align']) ?>>
    <?php esc_html(_e(' Left', cooks) );?>
    </option>
    <option value="right" <?php selected('right', $instance['text_align']) ?>>
    <?php esc_html(_e(' Right', cooks) );?>
    </option>
    <option value="center" <?php selected('center', $instance['text_align']) ?>>
    <?php esc_html(_e(' Center', cooks) );?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('portfolio_widget_category') ?>"> <?php _e('Enter Portfolio Category IDs : ',cooks) ?> </label>
 <input type="text" name="<?php echo $this->get_field_name('portfolio_widget_category') ?>" id="<?php echo $this->get_field_id('portfolio_widget_category') ?>" class="widefat" value="<?php echo $instance['portfolio_widget_category'] ?>" />
  <em><strong style="color:green;"><?php _e('Available Categories and IDs : ',cooks); ?> </strong><?php echo implode(',', $pf_cats_name); ?></em><br />
   <stong><?php _e('Note:',cooks); ?></strong><?php _e('Separate IDs with commas only',cooks); ?>
</p>
<p>
  <label for="<?php echo $this->get_field_id('kaya_portfolio_filter') ?>">
  <?php _e('Portfolio Filter Tabs',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('kaya_portfolio_filter') ?>" name="<?php echo $this->get_field_name('kaya_portfolio_filter') ?>">
    <option value="false" <?php selected('false', $instance['kaya_portfolio_filter']) ?>>
    <?php esc_html(_e('False', cooks )); ?>
    </option>
    <option value="true" <?php selected('true', $instance['kaya_portfolio_filter']) ?>>
    <?php esc_html(_e('True', cooks) );?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('filter_tab_bg_color'); ?>"><?php _e('Filter Tab BG Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('filter_tab_bg_color') ?>" id="<?php echo $this->get_field_id('filter_tab_bg_color') ?>" class="widefat" value="<?php echo $instance['filter_tab_bg_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('filter_tab_text_color'); ?>"><?php _e('Filter Tab Text Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('filter_tab_text_color') ?>" id="<?php echo $this->get_field_id('filter_tab_text_color') ?>" class="widefat" value="<?php echo $instance['filter_tab_text_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('filter_tab_active_bg_color'); ?>"><?php _e('Filter Tab Acive BG Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('filter_tab_active_bg_color') ?>" id="<?php echo $this->get_field_id('filter_tab_active_bg_color') ?>" class="widefat" value="<?php echo $instance['filter_tab_active_bg_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('filter_tab_active_text_color'); ?>"><?php _e('Filter Tab Active Text Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('filter_tab_active_text_color') ?>" id="<?php echo $this->get_field_id('filter_tab_active_text_color') ?>" class="widefat" value="<?php echo $instance['filter_tab_active_text_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('columns') ?>">
  <?php _e('Select Columns',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('columns') ?>" name="<?php echo $this->get_field_name('columns') ?>">
    <option value="5" <?php selected('5', $instance['columns']) ?>>
    <?php esc_html(_e('Column5', cooks)); ?>
    </option>
    <option value="4" <?php selected('4', $instance['columns']) ?>>
    <?php esc_html(_e('Column4', cooks) );?>
    </option>
    <option value="3" <?php selected('3', $instance['columns']) ?>>
    <?php esc_html(_e('Column3', cooks)); ?>
    </option>
    <option value="2" <?php selected('2', $instance['columns']) ?>>
    <?php esc_html(_e('Column2', cooks)); ?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('fluid_pf_gallery') ?>">
  <?php _e('Full Width Portfolio Gallery ',cooks)?>
  </label>
  &nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("fluid_pf_gallery"); ?>" name="<?php echo $this->get_field_name("fluid_pf_gallery"); ?>"<?php checked( (bool) $instance["fluid_pf_gallery"], true ); ?> />
</p>
<p>
  <label for="<?php echo $this->get_field_id('pf_display_orderby') ?>">
  <?php _e('Orderby',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('pf_display_orderby') ?>" name="<?php echo $this->get_field_name('pf_display_orderby') ?>">
    <option value="date" <?php selected('date', $instance['pf_display_orderby']) ?>>
    <?php esc_html(_e('Date', cooks)); ?>
    </option>
    <option value="menu_order" <?php selected('menu_order', $instance['pf_display_orderby']) ?>>
    <?php esc_html(_e('Menu Order', cooks)); ?>
    </option>
    <option value="title" <?php selected('title', $instance['pf_display_orderby']) ?>>
    <?php esc_html(_e('Title', cooks)); ?>
    </option>
    <option value="rand" <?php selected('rand', $instance['pf_display_orderby']) ?>>
    <?php esc_html(_e('Random', cooks) );?>
    </option>
    <option value="author" <?php selected('author', $instance['pf_display_orderby']) ?>>
    <?php esc_html(_e('Author', cooks)); ?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('pf_display_order') ?>">
  <?php _e('Order',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('pf_display_order') ?>" name="<?php echo $this->get_field_name('pf_display_order') ?>">
    <option value="ASC" <?php selected('ASC', $instance['pf_display_order']) ?>>
    <?php esc_html(_e('Ascending', cooks) );?>
    </option>
    <option value="DESC" <?php selected('DESC', $instance['pf_display_order']) ?>>
    <?php esc_html(_e('Descending', cooks) );?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('pf_img_height') ?>">
  <?php _e('Image Height(px)',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('pf_img_height') ?>" value="<?php echo esc_attr($instance['pf_img_height']) ?>" name="<?php echo $this->get_field_name('pf_img_height') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('post_title_bg_color'); ?>"><?php _e('Post Title BG Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('post_title_bg_color') ?>" id="<?php echo $this->get_field_id('post_title_bg_color') ?>" class="widefat" value="<?php echo $instance['post_title_bg_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('post_title_color'); ?>"><?php _e('Post Title Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('post_title_color') ?>" id="<?php echo $this->get_field_id('post_title_color') ?>" class="widefat" value="<?php echo $instance['post_title_color'] ?>" />
</p>
  <p>
  <label for="<?php echo $this->get_field_id('hide_lightbox_icon') ?>"><?php _e('Disable Lightbox icon',cooks)?></label>&nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_lightbox_icon"); ?>" name="<?php echo $this->get_field_name("hide_lightbox_icon"); ?>"<?php checked( (bool) $instance["hide_lightbox_icon"], true ); ?> />
  </p>
  <p>
  <label for="<?php echo $this->get_field_id('hide_post_link_icon') ?>"><?php _e('Disable Post Link icon',cooks)?></label>&nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_post_link_icon"); ?>" name="<?php echo $this->get_field_name("hide_post_link_icon"); ?>"<?php checked( (bool) $instance["hide_post_link_icon"], true ); ?> />
  </p>
  <p>
        <label for="<?php echo $this->get_field_id('hide_post_title') ?>"><?php _e('Disable Post Title',cooks)?></label>&nbsp;
       <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_post_title"); ?>" name="<?php echo $this->get_field_name("hide_post_title"); ?>"<?php checked( (bool) $instance["hide_post_title"], true ); ?> />
      </p>
    <p>
        <label for="<?php echo $this->get_field_id('hide_price') ?>"><?php _e('Disable Price',cooks)?></label>&nbsp;
       <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_price"); ?>" name="<?php echo $this->get_field_name("hide_price"); ?>"<?php checked( (bool) $instance["hide_price"], true ); ?> />
      </p>
  <label for="<?php echo $this->get_field_id('Popular_post_display') ?>">
  <?php _e('Popular Posts',cooks)?>
  </label>
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("Popular_post_display"); ?>" name="<?php echo $this->get_field_name("Popular_post_display"); ?>"<?php checked( (bool) $instance["Popular_post_display"], true ); ?> />
</p>
<p>
  <label for="<?php echo $this->get_field_id('portfolio_limit') ?>">
  <?php _e('Display Number of Images',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('portfolio_limit') ?>" value="<?php echo esc_attr($instance['portfolio_limit']) ?>" name="<?php echo $this->get_field_name('portfolio_limit') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('disable_pagination') ?>">
  <?php _e('Disable Pagination',cooks)?>
  </label>
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_pagination"); ?>" name="<?php echo $this->get_field_name("disable_pagination"); ?>"<?php checked( (bool) $instance["disable_pagination"], true ); ?> />
</p>
<?php

}
 }


 // Recent Blog post
 class cooks_Recent_Blog_Widget extends WP_Widget{
    public function __construct(){
        parent::__construct('kaya-recent-blog-post-widget',
            __('Cooks-Recent Blog Posts(PB)',cooks),
            array('description' => __('Displays Recent blog items',cooks), 'class' => 'recent_blog_post_widget')
        );
    }

    public function widget( $args, $instance ) {
      //echo $args['before_widget'];
      global $post;
      $instance=wp_parse_args($instance, array(
         'title' => __('Recent From Blog',cooks),
         'description' => '',
         'columns' => '4',
         'readmore_text' => __('Read More',cooks),
          'text_align'   => __('left',cooks),
         'title_color' => '#343434',
         'desc_color' => '#666666',
         'limit' => '2',
         'recent_blog_post' => '',
        'recent_blog_title_color' => '#343434',
        'recent_blog_desc_color' => '#757575',
        'recent_blog_date_color' => '#EF7360',
        'disable_description' => '',
        'disable_date' => '',
         'post_content_limit' => '8',
         'disable_comment' => '',
         'recent_blog_comment_color' => '#EF7360',
         'disable_pagination' => '',

      ));

         ?>
<div class="recent_blog_post">
  <?php  if( $instance['title'] ):
        echo '<div class="custom_title kaya_title_'.$instance['text_align'].'">';
           echo  '<h3 style="text-align:'.$instance['text_align'].'; color:'.$instance['title_color'].'!important;">'.$instance['title'].'</h3>';
        echo '</div>';

      ?>
  <div class="clear"> </div>
  <?php endif; ?>
  <ul>
    <?php
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;  
        $args = array('paged' => $paged, 'post_type' => 'post', 'orderby' => '', 'order' => 'DESC', 'posts_per_page' => $instance['limit'], 'cat' =>  $instance['recent_blog_post']);
        query_posts($args); 
           if(have_posts() ) : while( have_posts() ) : the_post();
        ?>
    <li>
      <?php  
        $comment_rand = rand(1,20); ?>
        <style>
          .comment_color-<?php echo $comment_rand; ?> a{
            color:<?php echo $instance['recent_blog_comment_color']; ?>!important;
          }
        </style>
      <?php

        $img_url = wp_get_attachment_url( get_post_thumbnail_id() ); ?>
      <a href="<?php echo the_permalink(); ?>" >
      <?php if( $img_url ){
           echo '<img src="'.aq_resize( $img_url, 60, 60, true ).'" class="alignleft" alt="'.$instance['title'].'" />';  
        }  
        echo '</a>';
        ?>
      <div class="description">
        <h5 style="color:<?php echo $instance['recent_blog_title_color']; ?>">
          <?php the_title(); ?>
        </h5>
        <?php if( $instance['disable_date'] != '1' && $instance['disable_date'] != 'on') : ?>
        <span style="color:<?php echo $instance['recent_blog_date_color']; ?>"><?php echo get_the_date('d.M.Y'); ?> </span><br />
        <?php endif; ?>
        <?php if( $instance['disable_description'] != '1' && $instance['disable_description'] != 'on') : ?>
        <span style="color:<?php echo $instance['recent_blog_desc_color']; ?>">
        <?php  echo strip_tags(cooks_content($instance['post_content_limit'])); ?>
        </span><br />
        <?php endif; ?>
        <?php if( $instance['disable_comment'] != '1' && $instance['disable_comment'] != 'on') : ?>
            <span  class="comment_color-<?php echo $comment_rand; ?>"><?php comments_popup_link(__('0 Comments',cooks ), __( '1 Comment', cooks ), __( '% Comments', cooks ) ); ?></span>
        <?php endif; ?>
      </div>
    </li>
    <?php endwhile; endif; ?>
  </ul>

  <?php //wp_reset_query(); 
  if( $instance['disable_pagination'] != 'on'){
          echo kaya_pagination();    
       }
 ?>
</div>
  <?php   ?>
<?php
      
         wp_reset_query();
    }

    public function form($instance){
         $blog_categories = get_categories('hide_empty=0');
    if( $blog_categories ){
        foreach ($blog_categories as $category) {
               $blog_cat_name[] = $category->name.'-'.$category->cat_ID;
                $blog_cat_id[] = $category->cat_ID;  
      } } else{   
          $blog_cat_id[] = '';
          $blog_cat_name[] ='';
      }
        $instance = wp_parse_args($instance, array(
           'title' => __('Recent From Blog',cooks),
           'description' => '',
           'columns'  => '4',
            'readmore_text' => __('Read More',cooks),
            'text_align'   => __('left',cooks),
            'title_color' => '#343434',
            'desc_color' => '#666666',
            'limit' => '2',
            'recent_blog_post' => implode(',', $blog_cat_id),
            'recent_blog_title_color' => '#343434',
            'recent_blog_desc_color' => '#757575',
            'recent_blog_date_color' => '#EF7360',
            'disable_description' => '',
            'disable_date' => '',
            'post_content_limit' => '8',
            'disable_comment' => '',
            'recent_blog_comment_color' => '#EF7360 ',
            'hide_post_link_icon' => '',
           'hide_lightbox_icon' => '',
           'disable_pagination' => '',

       ) ); ?>
<p>
  <lable for="<?php echo $this->get_field_id('title'); ?>">
  <?php _e('Title',cooks); ?>
  </label>
  <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo $this->get_field_name('title') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('title_color'); ?>">
  <?php _e('Title Color',cooks) ?>
  </label>
  <input type="text" name="<?php echo $this->get_field_name('title_color') ?>" id="<?php echo $this->get_field_id('title_color') ?>" class="widefat" value="<?php echo $instance['title_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('text_align') ?>">
  <?php _e('Title Position',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('text_align') ?>">
    <option value="left" <?php selected('left', $instance['text_align']) ?>>
    <?php esc_html(_e(' Left', cooks)); ?>
    </option>
    <option value="right" <?php selected('right', $instance['text_align']) ?>>
    <?php esc_html(_e(' Right', cooks)); ?>
    </option>
    <option value="center" <?php selected('center', $instance['text_align']) ?>>
    <?php esc_html(_e(' Center', cooks)); ?>
    </option>
  </select>
</p>
<p>
<label for="<?php echo $this->get_field_id('recent_blog_post') ?>">
<?php _e('Select Blog Category IDs',cooks) ?>
</label>
     <input type="text" name="<?php echo $this->get_field_name('recent_blog_post') ?>" id="<?php echo $this->get_field_id('recent_blog_post') ?>" class="widefat" value="<?php echo $instance['recent_blog_post'] ?>" />
       <em><strong style="color:green;"><?php _e('Available Categories and IDs : ',cooks); ?> </strong> <?php echo implode(',', $blog_cat_name); ?></em><br />
      <stong><?php _e('Note:',cooks); ?></strong><?php _e('Separate IDs with commas only',cooks); ?>
    </p>


<p>
  <label for="<?php echo $this->get_field_id('post_content_limit') ?>">
  <?php _e('Posts Content Limit',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('post_content_limit') ?>" value="<?php echo esc_attr($instance['post_content_limit']) ?>" name="<?php echo $this->get_field_name('post_content_limit') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('limit') ?>">
  <?php _e('Display Number of Posts',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('limit') ?>" value="<?php echo esc_attr($instance['limit']) ?>" name="<?php echo $this->get_field_name('limit') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('disable_pagination') ?>">
  <?php _e('Disable Pagination',cooks)?>
  </label>
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_pagination"); ?>" name="<?php echo $this->get_field_name("disable_pagination"); ?>"<?php checked( (bool) $instance["disable_pagination"], true ); ?> />
</p>
<p>
  <label for="<?php echo $this->get_field_id('disable_date') ?>">
  <?php _e('Disable Date',cooks)?>
  </label>
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_date"); ?>" name="<?php echo $this->get_field_name("disable_date"); ?>"<?php checked( (bool) $instance["disable_date"], true ); ?> />
</p>
<p>
  <label for="<?php echo $this->get_field_id('disable_description') ?>">
  <?php _e('Disable Description',cooks)?>
  </label>
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_description"); ?>" name="<?php echo $this->get_field_name("disable_description"); ?>"<?php checked( (bool) $instance["disable_description"], true ); ?> />
</p>
<p>
  <label for="<?php echo $this->get_field_id('disable_comment') ?>">
  <?php _e('Disable Comment',cooks)?>
  </label>
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_comment"); ?>" name="<?php echo $this->get_field_name("disable_comment"); ?>"<?php checked( (bool) $instance["disable_comment"], true ); ?> />
</p>
<p>
  <label for="<?php echo $this->get_field_id('recent_blog_title_color') ?>">
  <?php _e('Posts Title Color',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('recent_blog_title_color') ?>" value="<?php echo esc_attr($instance['recent_blog_title_color']) ?>" name="<?php echo $this->get_field_name('recent_blog_title_color') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('recent_blog_date_color') ?>">
  <?php _e('Posts Date Color',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('recent_blog_date_color') ?>" value="<?php echo esc_attr($instance['recent_blog_date_color']) ?>" name="<?php echo $this->get_field_name('recent_blog_date_color') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('recent_blog_desc_color') ?>">
  <?php _e('Posts Description Color',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('recent_blog_desc_color') ?>" value="<?php echo esc_attr($instance['recent_blog_desc_color']) ?>" name="<?php echo $this->get_field_name('recent_blog_desc_color') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('recent_blog_comment_color') ?>">
  <?php _e('Posts Comment Color',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('recent_blog_comment_color') ?>" value="<?php echo esc_attr($instance['recent_blog_comment_color']) ?>" name="<?php echo $this->get_field_name('recent_blog_comment_color') ?>" />
</p>

<?php  }
 }

 
 // List style

 class cooks_Custom_List_Box_Widget extends WP_Widget{
   public function __construct(){
   parent::__construct(  'kaya-list-box',
      __('Cooks-List Items (PB)',cooks),
      array( 'description' => __('add list items with custom icon',cooks), 'class' => 'kaya_list_box_widget' )
    );
    }
    public function widget( $args , $instance ){
        $instance = wp_parse_args($instance, array(
          'title' => __('Enter Title Here',cooks),
          'title_color' => '#333333',
          'list_box' => '',
          'text_align' => __('left',cooks),
          "image_size" => __("full",cooks),
          "image_id" => "",
          "thumb_src" => '',

             )); ?>
      <style>
          .custom_list_box-<?php echo $instance['image_id'] ?> ul li {

                background-image:url('<?php echo aq_resize( $instance['thumb_src'], 16, 16, true ); ?>');
                background-repeat:no-repeat;
                background-position: left 4px;
                background-repeat: no-repeat;
                list-style: none outside none;
                padding: 0 0 10px 28px !important; 
                margin-left: 0;

            }

          </style>
  <?php echo $args['before_widget'];

   if( $instance['title'] ):

       echo '<div class="custom_title kaya_title_'.$instance['text_align'].'">';
         echo  '<h3 style="text-align:'.$instance['text_align'].'; color:'.$instance['title_color'].'!important;">'.$instance['title'].'</h3>';
      echo '</div>';
      ?>
  <div class="clear"> </div>
  <?php endif; 
         echo '<div class="custom_list_box custom_list_box-'.$instance['image_id'].'">';
            echo $instance['list_box'];
         echo '</div>';
         echo $args['after_widget'];
    }

    public function form( $instance ){

       $instance = wp_parse_args( $instance, array(
          'title' => __('Enter Title Here',cooks),
          'title_color' => '#333333',
          'list_box' => '',
          'text_align' => __('left',cooks),
          "image_size" => __("full",cooks),
          "image_id" => "",
          "thumb_src" => '',
        ) );

        ?>
      <p style="text-align: center;"><img id="i<?php echo $this->get_field_id( 'thumb_src' ); ?>" src="<?php echo($instance["thumb_src"]); ?>" /></p>
      <p style="text-align: left;"> <a href="#" id="<?php echo $this->get_field_id( 'image_button' ); ?>" class="button">
        <?php _e('Upload List Icon',cooks); ?>
        </a> </p>
      <input id="<?php echo $this->get_field_id( 'image_id' ); ?>" name="<?php echo $this->get_field_name( 'image_id' ); ?>" type="hidden" value="<?php echo($instance["image_id"]); ?>" />
      <input id="<?php echo $this->get_field_id( 'thumb_src' ); ?>" name="<?php echo $this->get_field_name( 'thumb_src' ); ?>" type="hidden" value="<?php echo($instance["thumb_src"]); ?>" />
      <script type="text/javascript">

                    (function($) {
                          "use strict";
                          $(function() {
                        $("#<?php echo $this->get_field_id( 'image_button' ); ?>").click(function(e) {
                            e.preventDefault();
                            var custom_uploader = wp.media({title: 'Choose Team Image', button: {text: 'Use Image'}, multiple: false})
                            .on('select', function() {
                                var attachment = custom_uploader.state().get('selection').first().toJSON();
                                $('#<?php echo $this->get_field_id( 'image_id' ); ?>').val(attachment.id);
                                $('#<?php echo $this->get_field_id( 'thumb_src' ); ?>').val(attachment.sizes.thumbnail.url);
                                $('#i<?php echo $this->get_field_id( 'thumb_src' ); ?>').attr("src",$('#<?php echo $this->get_field_id( 'thumb_src' ); ?>').val());
                                console.log(attachment);
                            })
                            .open();
                        });
                        $('#i<?php echo $this->get_field_id( 'thumb_src' ); ?>').attr("src",$('#<?php echo $this->get_field_id( 'thumb_src' ); ?>').val());
                      });
                })(jQuery);
         </script>
        <small>
        <?php _e('Note: Use 16x16 size icons only',cooks); ?>
        </small>
        </p>
        <p>
          <lable for="<?php echo $this->get_field_id('title'); ?>">
          <?php _e('Title',cooks); ?>
          </label>
          <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo $this->get_field_name('title') ?>" />
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('title_color'); ?>">
          <?php _e('Title Color',cooks) ?>
          </label>
          <input type="text" name="<?php echo $this->get_field_name('title_color') ?>" id="<?php echo $this->get_field_id('title_color') ?>" class="widefat" value="<?php echo $instance['title_color'] ?>" />
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('text_align') ?>">
          <?php _e('Title Position',cooks)?>
          </label>
          <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('text_align') ?>">
            <option value="left" <?php selected('left', $instance['text_align']) ?>>
            <?php esc_html(_e(' Left', cooks)); ?>
            </option>
            <option value="right" <?php selected('right', $instance['text_align']) ?>>
            <?php esc_html(_e(' Right', cooks) );?>
            </option>
            <option value="center" <?php selected('center', $instance['text_align']) ?>>
            <?php esc_html(_e(' Center', cooks)); ?>
            </option>
          </select>
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('list_box') ?>">
          <?php _e('List Box',cooks)?>
          </label>
          <textarea type="text" id="<?php echo $this->get_field_id('list_box') ?>" class="widefat" name="<?php echo $this->get_field_name('list_box') ?>" value = "<?php echo $instance['list_box'] ?>" > <?php echo $instance['list_box'] ?></textarea>
        </p>
<?php  }

 }



 // Title Widget

 class cooks_Title_Widget extends WP_Widget{
   public function __construct(){
   parent::__construct(  'kaya-title',
      __('Cooks-Custom Title (PB)',cooks),
      array( 'description' => __('Use this widget to add custom title to the blocks',cooks) ,'class' => 'kaya_title' )

    );
    }
    public function widget( $args , $instance ){
        echo $args['before_widget'];
        $instance = wp_parse_args($instance, array(
            'title' => __('Add Custom Title',cooks),
            'description' => '',
            'desc_color' => '#666666',
            'title_color' => '#343434',
            'text_align' => __('left',cooks),
            'headig_styles' => '3',
         ) );

      if( $instance['title'] ):
          echo '<div class="custom_title kaya_title_'.$instance['text_align'].'">';
            echo  '<h'.$instance['headig_styles'].' style="text-align:'.$instance['text_align'].'; color:'.$instance['title_color'].'!important;">'.$instance['title'].'</h'.$instance['headig_styles'].'>';
          echo '</div>';
      ?>
<div class="clear"> </div>
<?php endif;
        echo  $args['after_widget'];
    }
    public function form( $instance ){
        $instance = wp_parse_args( $instance, array(
            'title' => __('Custom Title', cooks),
            'description' => __('Add Custom Title Description', cooks),
            'desc_color' => '#666666',
            'title_color' => '#343434',
            'text_align' => __('left',cooks),
            'headig_styles' => '3',
        ) );       ?>
<p>
  <label for="<?php echo $this->get_field_id('title'); ?>">
  <?php _e('Title',cooks) ?>
  </label>
  <input type="text" name="<?php echo $this->get_field_name('title') ?>" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo $instance['title'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('title_color'); ?>">
  <?php _e('Title Color',cooks) ?>
  </label>
  <input type="text" name="<?php echo $this->get_field_name('title_color') ?>" id="<?php echo $this->get_field_id('title_color') ?>" class="widefat" value="<?php echo $instance['title_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('headig_styles') ?>">
  <?php _e('Title Heading Style',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('headig_styles') ?>">
    <option value="1" <?php selected('1', $instance['headig_styles']) ?>>
    <?php esc_html(_e('Heading Style H1 ', cooks)); ?>
    </option>
    <option value="2" <?php selected('2', $instance['headig_styles']) ?>>
    <?php esc_html(_e('Heading Style H2 ', cooks)); ?>
    </option>
    <option value="3" <?php selected('3', $instance['headig_styles']) ?>>
     <?php esc_html(_e('Heading Style H3 ', cooks) );?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('text_align') ?>">
  <?php _e('Title Position',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('text_align') ?>">
    <option value="left" <?php selected('left', $instance['text_align']) ?>>
    <?php esc_html(_e(' Left', cooks) );?>
    </option>
    <option value="right" <?php selected('right', $instance['text_align']) ?>>
    <?php esc_html(_e('Right', cooks)); ?>
    </option>
    <option value="center" <?php selected('center', $instance['text_align']) ?>>
    <?php esc_html(_e(' Center', cooks)); ?>
    </option>
  </select>
</p>
<?php  }

 }
 // Vspace Widget

 class cooks_vspace_Widget extends WP_Widget{
   public function __construct(){
   parent::__construct(  'kaya-vspace',
      __('Cooks-Vertical Space (PB)',cooks),
      array( 'description' => __('Use this widget to add vertical height in between block rows',cooks),'class' => 'kaya_vspace' )
    );
   }
    public function widget( $args , $instance ){
        echo $args['before_widget'];
        $instance = wp_parse_args($instance, array(
            'height' => '20',
         ) );
        echo '<div class="vspace" style="margin-bottom: '.$instance['height'].'px;"> </div>';
        echo  $args['after_widget'];

    }
    public function form( $instance ){
        $instance = wp_parse_args( $instance, array(

            'height' => '30',

        ) );
        ?>
<p>
  <label for="<?php echo $this->get_field_id('height'); ?>">
  <?php _e('Height(px)',cooks) ?>
  </label>
  <input type="text" name="<?php echo $this->get_field_name('height') ?>" id="<?php echo $this->get_field_id('height') ?>" class="widefat" value="<?php echo $instance['height'] ?>" />
</p>
<?php  }

 }

 //kaya Slider

 class cooks_Slider_Widget extends WP_Widget{
    public function __construct(){
     parent::__construct(  'kaya-slider',
      __('Cooks-Slider (PB)',cooks),
      array( 'description' => __('Displays slider from Kaya slider category', cooks) ,'class' => 'kaya_slider' )
    );
   }
    public function widget( $args , $instance ){
      echo $args['before_widget'];
        $instance = wp_parse_args($instance, array(
              'slide_effect' => __('slide',cooks),
              'slide_caption' => '',
              'slider_easing' => __('swing',cooks),
              'slider_height' =>'450',
              'slider_cat' => '',
              'slide_link' => '',
              'slider_pause_time' => '4000',
              'adaptive_height' => __('false',cooks),
              'slide_auto_play' => __('true',cooks),
              'slider_width' => '1100',
         ) );       

    $slide_random = rand(1,50);  ?>

  <script type="text/javascript">  
      (function($) {
        "use strict";
      $(function() {
         $('.bxslider<?php echo $slide_random; ?>').bxSlider({
            useCSS: false,
            pause : <?php echo $instance['slider_pause_time'] ?>,
            easing : "<?php echo $instance['slider_easing'] ?>",
            speed: 1500,
            mode:"<?php echo $instance['slide_effect'] ?>",
            auto : <?php echo $instance['slide_auto_play']; ?>,
            adaptiveHeight : <?php echo $instance['adaptive_height']; ?>
           });
       });
    })(jQuery);
  </script>
  <div id="bx_slider_wrapper">
     <ul class="bxslider<?php echo $slide_random; ?>"  class="slider_wrap">
      <?php
      
 $array_val = ( !empty( $instance['slider_cat'] )) ? explode(',',  $instance['slider_cat']) : '';
if( $array_val ) {
          $loop = new WP_Query(array( 'post_type' => 'slider',  'orderby' => 'menu_order', 'posts_per_page' =>10,'order' => 'DESC',  'tax_query' => array('relation' => 'AND', array( 'taxonomy' => 'slider_category',   'field' => 'id', 'terms' => $array_val  ), )));
          }else{
             $loop = new WP_Query(array('post_type' => 'slider', 'taxonomy' => 'slider_category','term' => $instance['slider_cat'], 'orderby' => 'menu_order', 'posts_per_page' =>10,'order' => 'DESC'));
          }
      if ( $loop->have_posts() ) : while ( $loop->have_posts() ) : $loop->the_post(); ?>
        <li>
            <?php
            global $post;

  $slider_link=get_post_meta(get_the_ID(),'customlink' ,true);
  $slider_imglink= $slider_link ? $slider_link: get_permalink($post->ID);
  $slide_text_color=get_post_meta($post->ID,'slide_text_color',true) ? get_post_meta($post->ID,'slide_text_color',true) : '#ffffff';
  $slider_target_link= get_post_meta($post->ID,'slider_target_link',true);
  $slide_description= get_post_meta($post->ID,'slide_description',true);
  $slider_imglink= $slider_link ? $slider_link: get_permalink($post->ID);
  $disable_slide_content = get_post_meta($post->ID,'disable_slide_content',true);
  if( $slider_target_link == '1' ){ $target_link_class='target=_blank';}else{ $target_link_class=""; }
    if($slider_link){
           echo '<a href="'.$slider_imglink.'" '.$target_link_class.' >';
    }
             global $post;
             $slider_img_width =  $instance['slider_width'] ? $instance['slider_width'] : '1160';       
             $img_url = wp_get_attachment_url( get_post_thumbnail_id() ); //get img URL
             if( $img_url ):
                 $height = ( $instance['adaptive_height'] == 'true' ) ? '' : $instance['slider_height'];
                 echo '<img src="'.aq_resize( $img_url, $slider_img_width, $height, true ).'" class="" alt="'.get_the_title().'"  />';
             else:
                  echo '<img src="'.get_template_directory_uri().'/images/defult_featured_img.png" style="width:'.$slider_img_width.'px; height:'.$instance['slider_height'].'px;" alt="'.get_the_title().'" >';
             endif;
           echo '</a>';
         if($disable_slide_content == "0") { ?>
               <div class="caption">
                    <h4><?php echo the_title(); ?></h4>
              </div>
          <?php } ?>
         <?php endwhile; // End the loop. Whew. ?>
      </li>
      <?php else :
          echo '<li><img src="'.get_template_directory_uri().'/images/defult_featured_img.png" width="100%" height="400"  alt="'.get_the_title().'" ></li>';
       endif; ?>
      </ul>
    </div>
    <?php wp_reset_query(); ?>
    <div class="clear"></div>
    <?php     echo  $args['after_widget'];
       }

public function form( $instance ){
        $kaya_terms=  get_terms('slider_category','');
     if( $kaya_terms ){   
      foreach ($kaya_terms as $kaya_term) { 
        $kaya_cats_name[] = $kaya_term->name.'- '. $kaya_term->term_id;
        $kaya_cats_id[] = $kaya_term->term_id;
      } $slider_items = implode(',', $kaya_cats_id); }else{ $slider_items = '';  $kaya_cats_name[] = '';}
        $instance = wp_parse_args( $instance, array(

              'slide_effect' => __('slide',cooks),
              'slide_caption' => '',
              'slider_easing' => __('swing',cooks),
              'slider_height' =>'450',
              'slider_cat' => $slider_items,
              'slide_link' => '',
              'slider_pause_time' => '4000',
              'adaptive_height' => __('false',cooks),
              'slide_auto_play' => __('true',cooks),
              'slider_width' => '1100'
        ) );
        ?>
    <p>
      <label for="<?php echo $this->get_field_id('slider_cat') ?>">   <?php _e('Enter Kaya Slider Category IDs : ',cooks) ?>  </label>
          <input type="text" name="<?php echo $this->get_field_name('slider_cat') ?>" id="<?php echo $this->get_field_id('slider_cat') ?>" class="widefat" value="<?php echo $instance['slider_cat'] ?>" />
      <em><strong style="color:green;"><?php _e('Available Categories and IDs : ',cooks); ?> </strong> <?php echo implode(', ', $kaya_cats_name); ?></em><br />
  <stong><?php _e('Note:',cooks); ?></strong><?php _e('Separate IDs with commas only',cooks); ?>
    </p>
  <p>
  <p>
    <label for="<?php echo $this->get_field_id('slide_auto_play') ?>">
    <?php _e('Auto Play',cooks)?>
    </label>
    <select id="<?php echo $this->get_field_id('slide_auto_play') ?>" name="<?php echo $this->get_field_name('slide_auto_play') ?>">
      <option value="true" <?php selected('true', $instance['slide_auto_play']) ?>>
      <?php esc_html(_e('True', cooks)); ?>
      </option>
      <option value="false" <?php selected('false', $instance['slide_auto_play']) ?>>
      <?php esc_html(_e('False', cooks)); ?>
      </option>
    </select>
  </p>
  <p>
    <label for="<?php echo $this->get_field_id('slide_effect') ?>">
    <?php _e('Slide Transition Effect',cooks) ?>
    </label>
    <select id="<?php echo $this->get_field_id('slide_effect') ?>" name="<?php echo $this->get_field_name('slide_effect') ?>">
      <option value="horizontal" <?php selected('show', $instance['slide_effect']) ?>>
      <?php esc_html(_e('Horizontal', cooks) );?>
      </option>
      <option value="vertical" <?php selected('vertical', $instance['slide_effect']) ?>>
      <?php esc_html(_e('Vertical', cooks)); ?>
      </option>
      <option value="fade" <?php selected('fade', $instance['slide_effect']) ?>>
      <?php esc_html(_e('Fade', cooks)); ?>
      </option>
    </select>
  </p>
  <p>
    <label for="<?php echo $this->get_field_id('slider_easing') ?>">
    <?php _e('Slide Easing Effect',cooks) ?>
    </label>
    <input type="text" name="<?php echo $this->get_field_name('slider_easing') ?>" id="<?php echo $this->get_field_id('slider_easing') ?>" class="widefat" value="<?php echo $instance['slider_easing'] ?>" />
    <small>
    <?php _e("Enter easing effect Ex:linear, swing,easeOutElastic <br> for more transition effects  <a href='http://jqueryui.com/resources/demos/effect/easing.html' target='_blank'>  click here   </a>",cooks); ?>
    </small> </p>
  <label for="<?php echo $this->get_field_id('slider_pause_time') ?>">
  <?php _e('Slide Pause Time',cooks) ?>
  </label>
  <input type="text" name="<?php echo $this->get_field_name('slider_pause_time') ?>" id="<?php echo $this->get_field_id('slider_pause_time') ?>" class="widefat" value="<?php echo $instance['slider_pause_time'] ?>" />
  <small>
  <?php _e('The amount of time (in ms) between each auto transition , Ex: 4000',cooks); ?>
  </small>
  </p>
  <p>
    <label for="<?php echo $this->get_field_id('adaptive_height') ?>">
    <?php _e('Auto Height',cooks)?>
    </label>
    <select id="<?php echo $this->get_field_id('adaptive_height') ?>" name="<?php echo $this->get_field_name('adaptive_height') ?>">
      <option value="true" <?php selected('true', $instance['adaptive_height']) ?>>
      <?php esc_html(_e('True', cooks)); ?>
      </option>
      <option value="false" <?php selected('false', $instance['adaptive_height']) ?>>
      <?php esc_html(_e('False', cooks)); ?>
      </option>
    </select>
  </p>
  <p>
    <label for="<?php echo $this->get_field_id('slider_width') ?>">
    <?php _e('Slider Width (px)',cooks) ?>
    </label>
    <input type="text" name="<?php echo $this->get_field_name('slider_width') ?>" id="<?php echo $this->get_field_id('slider_width') ?>" class="widefat" value="<?php echo $instance['slider_width'] ?>" />
  </p>
  <p>
    <label for="<?php echo $this->get_field_id('slider_height') ?>">
    <?php _e('Slider Height (px)',cooks) ?>
    </label>
    <input type="text" name="<?php echo $this->get_field_name('slider_height') ?>" id="<?php echo $this->get_field_id('slider_height') ?>" class="widefat" value="<?php echo $instance['slider_height'] ?>" />
    <small>
    <?php _e('Ex: 400<br /> Note: It works only when auto height is false',cooks); ?>
    </small> </p>
<?php  }

 }
 /* Dropcap */

class cooks_Dropcap_Widget extends WP_Widget {
  public function __construct() {
    // widget actual processes
    parent::__construct(

      'dropcap-widget', // Base ID

      __('Cooks-Dropcap (PB)', cooks), // Name

      array( 'description' => __( 'Use this widget to create drop cap with text or Font Awesome icons', cooks ), ) // Args

    );

  }
  public function widget( $args, $instance ) {

    echo $args['before_widget'];

  
  $instance = wp_parse_args( $instance, array(

        'title' => __('Dropcap Title',cooks),
        'dropcap_text' => 'A',
        'dropcap_bg_color' => '#ffffff',
        'description' => __('Enter Description Here',cooks),
        'readmore_text' => '',
        'link' => '#',
        'disable_dropcap_link' => '',
        'dropcap_color' => '#333333',
        'title_color' => '#333333',
        'description_color' => '#787878',
        'dropap_align' => __('center',cooks),
        'awesome_icon_name' => '',
        'dropap_font_size' => '',
        'text_wrap' => __('false',cooks),
        'border_radius' => '',
        'border_color' => '#000000',

    ) ); 
  $dropcap_rand = rand(1,500);
  if( $instance['dropcap_bg_color'] ):
    ?>
      <style type="text/css">
            .dropca-<?php echo $dropcap_rand; ?> .dropcap_bg:hover, .dropca-<?php echo $dropcap_rand; ?> .dropcap_bg:hover {
                background-color: <?php echo $instance['dropcap_color']; ?>!important;
                color: <?php echo $instance['dropcap_bg_color']; ?>!important;
            }
          .dropcap a:hover{
            opacity: 0.8!important;
          }
      </style>
  <?php 
  endif;
 if($instance['dropcap_bg_color'] || $instance['border_color'] ): 

  $padding = round($instance['dropap_font_size'] / 4).'px';
else:
  $padding = '0';

endif;

if($instance['border_color']){

  $border_color = '1px solid '.$instance['border_color'];

  $border_shadow = '0px 3px 0px 0px '.$instance['border_color'];

}else{ $border_color = '0px solid '.$instance['border_color']; $border_shadow =''; }

 $line_height = round($instance['dropap_font_size'] /2 ).'px';

 $text_wrap = $instance['text_wrap'] == 'true' ? 'inherit' : 'hidden';

 $icon_size = round($instance['dropap_font_size'] / 2);

  $dropcap_data = array(

      'width' => round( $instance['dropap_font_size'] / 2 ).'px',

      'height' => round( $instance['dropap_font_size'] / 2).'px',
     'line-height' => $line_height,
      'font-size' => $icon_size.'px',
      'background-color' => $instance['dropcap_bg_color'],
      'color' => $instance['dropcap_color'].'',
      'padding' =>  $padding,
      'border' => $border_color,
      'border-radius' => $instance['border_radius'].'%',
  );

   $dropcap_styles =array();

    foreach ($dropcap_data as $key => $value) {

       $dropcap_styles[] = $key.':'.$value;

   }

   ?>
<div class="dropcap dropcap_<?php echo $instance['dropap_align']; ?> dropca-<?php echo $dropcap_rand; ?>  " > 
  <?php if($instance['disable_dropcap_link'] != 'on' ): ?>
    <a href="<?php echo esc_url($instance['link']); ?>" >
     <?php endif; 
    if( $instance['awesome_icon_name'] || $instance['dropcap_text']  ){ 
     ?>
    <div class="dropcap_bg align<?php echo $instance['dropap_align']; ?>  <?php echo $this->get_field_id('dropcap_bg_color') ?>" style="<?php echo  implode('; ',$dropcap_styles); ?>">
    <?php
          if( $instance['awesome_icon_name'] ){
               echo ' <i class="fa '.$instance['awesome_icon_name'].'" > </i>';
          }else {   ?>
            <strong style="font-weight:blod;"><?php echo $instance['dropcap_text']; ?></strong>
      <?php  } ?>
      </div>
     <?php } ?> 
<?php if( $instance['link'] ){ ?> 
</a> 
<?php } ?>

  <div class="description" style="overflow:<?php echo $text_wrap; ?>">
     <?php if( $instance['link'] ){ ?>
    <a href="<?php echo esc_url($instance['link']); ?>" >
    <?php } ?>
      <h3 style="color:<?php echo $instance['title_color']; ?>!important; text-align:<?php echo $instance['dropap_align']; ?>"><?php echo $instance['title']; ?></h3>
    <?php if( $instance['link'] ){ ?> </a> <?php } ?>
    <p style="color:<?php echo $instance['description_color']; ?>!important; text-align:<?php echo $instance['dropap_align']; ?>"><?php echo $instance['description']; ?></p>
    <?php if( $instance['readmore_text'] ): echo '<a href="'.esc_url($instance['link']).'" class="readmore readmore-1">'.esc_attr($instance['readmore_text']).'</a>'; endif;  ?>
  </div>
</div>
<?php echo $args['after_widget'];

  }



  public function form( $instance ) {

    $instance = wp_parse_args( $instance, array(

       'title' => __('Dropcap Title',cooks),
        'dropcap_text' => 'A',
        'dropcap_bg_color' => '#343434',
        'description' => __('Enter Description Here',cooks),
        'readmore_text' => '',
        'link' => '#',
        'disable_dropcap_link' => '',
        'dropcap_color' => '#ffffff',
        'title_color' => '#343434',
        'description_color' => '#666666',
        'dropap_align' => __('center',cooks),
        'awesome_icon_name' => '',
        'dropap_font_size' => '',
        'text_wrap' => __('false',cooks),
        'border_radius' => '100',
        'border_color' => '#333',

    ) );

    $font_sizes = array(16,24,32,48,64,128);

    ?>
<p>
  <label for="<?php echo $this->get_field_id('awesome_icon_name') ?>">
  <?php _e('Awesome Icon Name',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('awesome_icon_name') ?>" name="<?php echo $this->get_field_name('awesome_icon_name') ?>" value="<?php echo esc_attr($instance['awesome_icon_name']) ?>" />
  <small>
  <?php _e('Ex: fa-home, for More Awesome icons click',cooks); ?>
  <a href='http://fontawesome.io/icons/' target='_blank'> click here </a></small> </p>
<p>
  <label for="<?php echo $this->get_field_id('dropcap_text') ?>">
  <?php _e('Enter Dropcap Text',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('dropcap_text') ?>" name="<?php echo $this->get_field_name('dropcap_text') ?>" value="<?php echo esc_attr($instance['dropcap_text']) ?>" />
  <small>
  <?php _e('Ex: A  <stong> Note: </strong>It Works only when above icon name field is empty ',cooks) ?>
  </small> </p>
<p>
  <label for="<?php echo $this->get_field_id('dropap_font_size') ?>">
  <?php _e('Dropcap Size',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('dropap_font_size') ?>" name="<?php echo $this->get_field_name('dropap_font_size') ?>">
    <?php  foreach ($font_sizes as $font_size) {
             echo '<option value="' .$font_size. '"  id="' .$font_size. '"',  $instance['dropap_font_size'] == $font_size  ? 'selected = "selected"' : '',' >'.$font_size.'</option>';

            }?>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('dropcap_bg_color') ?>">
  <?php _e('Dropcap Background Color',cooks) ?>
  </label>Button Text 
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('dropcap_bg_color') ?>" name="<?php echo $this->get_field_name('dropcap_bg_color') ?>" value="<?php echo esc_attr($instance['dropcap_bg_color']) ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('dropcap_color') ?>">
  <?php _e('Dropcap Text Color',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('dropcap_color') ?>" name="<?php echo $this->get_field_name('dropcap_color') ?>" value="<?php echo esc_attr($instance['dropcap_color']) ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('border_color') ?>">
  <?php _e('Dropcap Border Color',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('border_color') ?>" name="<?php echo $this->get_field_name('border_color') ?>" value="<?php echo esc_attr($instance['border_color']) ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('border_radius') ?>">
  <?php _e('Dropcap Border Radius ( % )',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('border_radius') ?>" name="<?php echo $this->get_field_name('border_radius') ?>" value="<?php echo esc_attr($instance['border_radius']) ?>" />
  <small>
  <?php _e('Ex:10,20 <stont> Note: </stong>It applies only percentage(%)',cooks) ?>
  </small> </p>
<p>
  <label for="<?php echo $this->get_field_id('title') ?>">
  <?php _e('Title',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('title_color') ?>">
  <?php _e('Title Color',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('title_color') ?>" name="<?php echo $this->get_field_name('title_color') ?>" value="<?php echo esc_attr($instance['title_color']) ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('description') ?>">
  <?php  _e('Description' ,cooks); ?>
  </label>
  <textarea type="text" class="widefat" name="<?php echo $this->get_field_name('description') ?>" id="<?php echo $this->get_field_id('description') ?>" ><?php echo esc_attr($instance['description']) ?></textarea>
</p>
<p>
  <label for="<?php echo $this->get_field_id('description_color') ?>">
  <?php _e('Description Color',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('description_color') ?>" name="<?php echo $this->get_field_name('description_color') ?>" value="<?php echo esc_attr($instance['description_color']) ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('readmore_text') ?>">
  <?php _e('Readmore Button Text',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('readmore_text') ?>" name="<?php echo $this->get_field_name('readmore_text') ?>" value="<?php echo esc_attr($instance['readmore_text']) ?>" />
  <small>
  <?php _e('<stong>Note: </strong>Keep it empty to not display the readmore button ',cooks) ?>
  </small> </p>

  <p>
  <label for="<?php echo $this->get_field_id('disable_dropcap_link') ?>"><?php _e('Disable Dropcap Link',cooks)?></label>&nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_dropcap_link"); ?>" name="<?php echo $this->get_field_name("disable_dropcap_link"); ?>"<?php checked( (bool) $instance["disable_dropcap_link"], true ); ?> />
  </p>


<p>
  <label for="<?php echo $this->get_field_id('link') ?>">
  <?php _e('Link',cooks) ?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('link') ?>" name="<?php echo $this->get_field_name('link') ?>" value="<?php echo esc_attr($instance['link']) ?>" />
  <small>
  <?php _e('Ex:http://www.google.com',cooks) ?>
  </small> </p>
<p>
  <label for="<?php echo $this->get_field_id('dropap_align') ?>">
  <?php _e('Dropcap Position',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('dropap_align') ?>" name="<?php echo $this->get_field_name('dropap_align') ?>">
    <option value="left" <?php selected('left', $instance['dropap_align']) ?>>
    <?php esc_html(_e('Position Left',cooks)); ?>
    </option>
    <option value="right" <?php selected('right', $instance['dropap_align']) ?>>
    <?php esc_html(_e('Position Right', cooks)); ?>
    </option>
    <option value="center" <?php selected('center', $instance['dropap_align']) ?>>
    <?php esc_html(_e('Position Center',cooks) );?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('text_wrap') ?>">
  <?php _e('Text Wrapping',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('text_wrap') ?>" name="<?php echo $this->get_field_name('text_wrap') ?>">
    <option value="true" <?php selected('true', $instance['text_wrap']) ?>>
    <?php esc_html(_e('True',cooks)); ?>
    </option>
    <option value="false" <?php selected('false', $instance['text_wrap']) ?>>
    <?php esc_html(_e('False',cooks) );?>
    </option>
  </select>
</p>
<?php

  }

}

// Draggable slider

class cooks_Draggable_slider_Widget extends WP_Widget{
    public function __construct(){
        parent::__construct('Cooks-draggable-slider-widget',
            __('Cooks-Draggable Slider (PB)',cooks),
            array('description' => __('Displays portfolio and kaya slider items as draggable slider',cooks), 'class' => 'draggable_widget')
        );

    }
    public function widget( $args, $instance ) {
      echo $args['before_widget'];
          global $post;
      $instance=wp_parse_args($instance, array(
        'title' => __('Portfolio Slider Title',cooks),
        'description' => '',
        'readmore_text' => __('Read More',cooks),
        'text_align'   => __('left',cooks),
        'title_color' => '#343434',
        'draggable_img_height' => '400',
        'draggable_project_link' => '#',
        'draggable_project_title' => '',
        'hide_slide_content' => '',
        'Popular_post_display' => '',
        'draggable_display_orderby' => __('date',cooks),
        'draggable_display_order' => __('DESC',cooks),
        'draggable_slide_items' => '4',
        'draggable_auto_play' => __('true',cooks),
        'select_cat_type' => '',
        'kaya_slider_cat' => '',
        'pf_slider_cat' => '',
        'draggable_title_color' => '#323232',
        'draggable_content_bg_color' => '#ffffff',
        'hide_lightbox_icon' => '',
        'hide_post_link_icon' => '',
        'hide_price' => ''

      ));

      if( $instance['title'] ):
            echo '<div class="portfolio_title custom_title kaya_title_'.$instance['text_align'].'">';
              echo  '<h3 style="text-align:'.$instance['text_align'].'; color:'.$instance['title_color'].'!important;">'.$instance['title'].'</h3>';
         echo '</div>';

        ?>
      <div class="clear"> </div>
      <?php endif;
       $rand = rand(1,50);
        ?>
        <?php $post_icon = ( $instance['hide_lightbox_icon'] == 'on' ) ? "50%" : '30%'; ?>
        <?php $post_class = ( $instance['hide_lightbox_icon'] == 'on' ) ? "left" : 'right'; ?>
        <?php $lightbox_icon = ( $instance['hide_post_link_icon'] == 'on' ) ? "50%" : '30%'; ?>
      <script type="text/javascript">
      (function($) {
        "use strict";
        $(function() {
          $(".kaya_portfolio_widget_sliders<?php echo $rand; ?>").owlCarousel({
          navigation : false,
          autoPlay : <?php echo $instance['draggable_auto_play']; ?>,
          stopOnHover : true,
          items : <?php echo $instance['draggable_slide_items'] ?>,    
       });

        // Hover Effects
        $('.draggable_slider .item_container').hover(function(){
          $(this).find('img').fadeTo(500,0.6);
          $(this).find('.link_to_image, .link_to_video').css({'left':'-100px','display':'block'}).stop().animate({'left':'<?php echo $lightbox_icon; ?>', opacity:1},600);
          $(this).find('.link_to_post').css({'<?php echo $post_class; ?>':'-100px','display':'block'}).stop().animate({'<?php echo $post_class; ?>':'<?php echo $post_icon; ?>',opacity:1},600);
          //alert('test');
        },function(){
          $(this).find('img').fadeTo(500,1);
          $(this).find('.link_to_image, .link_to_video').css({'left':'100','display':'block'}).stop().animate({'left':'-<?php echo $lightbox_icon; ?>',opacity:0},600);
          $(this).find('.link_to_post').css({'<?php echo $post_class; ?>':'100px','display':'block'}).stop().animate({'<?php echo $post_class; ?>':'-<?php echo $post_icon; ?>',opacity:0},600);
      }); 

         });

      })(jQuery);
     </script>
    <?php   
      switch ($instance['draggable_slide_items']) {
      case '5':
       $img_width = '350';
        break;
      case '4':
        $img_width = '400';
        break;
      case '3':
        $img_width = '400';
        break;
      case '2':
        $img_width = '600';
        break;
      case '1':
        $img_width = '1100';
        break;  
      default:
        $img_width = '400';
        break;
      }    ?>
    <div class="Portfolio_gallery cooks_portfolio_gallery">
      <?php 
        $post_type = ( $instance['select_cat_type'] == 'portfolio_category' ) ? 'portfolio' : 'slider';
        $post_terms = ( $instance['select_cat_type'] == 'portfolio_category' ) ? $instance['pf_slider_cat'] : $instance['kaya_slider_cat'];
      ?>
    <div id="kaya_portfolio_widget_slider" class="kaya_portfolio_widget_sliders<?php echo $rand; ?>">
     <?php
    if( $instance['select_cat_type'] == 'portfolio_category'){
      $array_val = ( !empty($instance['pf_slider_cat']) ) ? explode(',', $instance['pf_slider_cat'])  :  '';
    }
    elseif( $instance['select_cat_type'] == 'slider_category'){
     $array_val = ( !empty($instance['kaya_slider_cat']) ) ? explode(',', $instance['kaya_slider_cat'])  :  '';
    } else{ $array_val = '';   } 

    if( ( $instance["Popular_post_display"] == '1') && ($instance["Popular_post_display"] == 'on') ){
      $loop = new WP_Query(array('post_type' => $post_type , 'showposts' => -1, 'meta_key' => 'post_views_count', 'orderby' => 'meta_value_num', 'field' => 'id', 'order' => $instance['draggable_display_order'], 'taxonomy' => $instance['select_cat_type'] ));

    }else{
         if( is_array($array_val ) ){
          $loop = new WP_Query(array( 'post_type' => $post_type,  'orderby' => $instance['draggable_display_orderby'], 'posts_per_page' =>-1,'order' => $instance['draggable_display_order'],  'tax_query' => array('relation' => 'AND', array( 'taxonomy' => $instance['select_cat_type'],   'field' => 'id', 'terms' => $array_val  ) )));
          }else{
                 $loop = new WP_Query(array('post_type' => $post_type, 'taxonomy' => $instance['select_cat_type'],'term' => '', 'orderby' => $instance['draggable_display_orderby'], 'posts_per_page' =>-1,'order' => $instance['draggable_display_order']));
          }
        }
    if( $loop->have_posts() ) : while( $loop->have_posts() ) : $loop->the_post();  
        $title=get_the_title($post->Id);
        $img_url=wp_get_attachment_url( get_post_thumbnail_id() );
         $pf_link_new_window=get_post_meta(get_the_ID(),'pf_link_new_window' ,true);
            if($pf_link_new_window == '1') { $pf_target_link ="_blank"; }else{ $pf_target_link ='_self'; }
          $lightbox_url =  get_template_directory_uri().'/images/defult_featured_img.png';
         $featured_img = $img_url ? $img_url : $lightbox_url;
        $permalink = get_permalink();
        $Porfolio_customlink=get_post_meta($post->ID,'Porfolio_customlink',true);
        $pf_customlink = $Porfolio_customlink ? $Porfolio_customlink : $permalink;
         $video_url= get_post_meta($post->ID,'video_url',true);
           $lightbox_type = $video_url ? trim($video_url) : $featured_img;
           $class = $video_url ? 'link_to_video' : 'link_to_image';
        $height = $instance['draggable_img_height'] ? $instance['draggable_img_height'] : '300';
       echo '<div class="draggable_slider">';
            echo '<div class="owl_slider_img">';
              echo '<div class="item_container">';
                if( $img_url ):
                  echo '<img src="'.aq_resize( $img_url, $img_width , $height, true ).'" class=""  alt="'.$title.'"  />';
                else:
                  echo '<img src="'.get_template_directory_uri().'/images/defult_featured_img.png" alt="'.$title.'" class="owl_slider_margin" style="width:1000px; height:300px;">';
                endif; $price = get_post_meta(get_the_ID(),'fooditem_price',true);
              if( $price && $instance['hide_price'] != 'on' ): echo '<span class="item_price">'.$price.'</span>'; endif; ?>
                 <?php if( $instance['hide_lightbox_icon'] != '1' && $instance['hide_lightbox_icon'] != 'on' ): ?>
                <a class="<?php echo $class; ?> pf_images" rel="prettyPhoto['gallery']" title="<?php echo the_title();?>" href="<?php echo $lightbox_type; ?>">&nbsp;</a>
              <?php endif; ?>
               <?php if( $instance['hide_post_link_icon'] != '1' && $instance['hide_post_link_icon'] != 'on' ): ?>
                <a class="link_to_post" target="<?php echo $pf_target_link;  ?>" href="<?php echo $pf_customlink; ?>">&nbsp; </a>
              <?php endif; ?>
            </div>
            <?php if( $instance['hide_slide_content'] != '1' && $instance['hide_slide_content'] != 'on' ): ?>
             <div class="slider_post_content" style="background-color:<?php echo $instance['draggable_content_bg_color']; ?>">
            <?php echo '<h4 style="color:'.$instance['draggable_title_color'].';">'.get_the_title().'</h4>'; ?>
         </div> 
                 <?php endif; ?> 
      </div>
       </div>

    <?php endwhile; endif; ?>
    </div>
    <?php wp_reset_query(); ?>
    </div>
    <?php
    echo $args['after_widget'];
    }

    public function form($instance){

    $portfolio_terms=  get_terms('portfolio_category','');
    if( $portfolio_terms ){
      foreach ($portfolio_terms as $portfolio_term) { 
         $pf_cats_name[] = $portfolio_term->name.' - '.$portfolio_term->term_id;
         $pf_cats_id[] = $portfolio_term->term_id;
      }
    }else{
      $pf_cats_name[] = '';
      $pf_cats_id[] = '';
    }
     $kayaslider_array =get_terms('slider_category','hide_empty=1');
    if( $kayaslider_array ){
        foreach ($kayaslider_array as $sliders) {
               $kaya_cat_name[] = $sliders->name.' - '.$sliders->term_id;
                $kaya_cat_id[] =$sliders->term_id;
      } } else{
          $kaya_cat_name[] = '';
           $kaya_cat_id[] ='';
      }

      $instance=wp_parse_args($instance, array(
        'title' => __('Portfolio Slider Title',cooks),
        'description' => '',
        'readmore_text' => __('Read More',cooks),
        'text_align'   => __('left',cooks),
        'title_color' => '#343434',
        'draggable_img_height' => '400',
        'draggable_project_link' => '#',
        'draggable_project_title' => '',
        'hide_slide_content' => '',
        'Popular_post_display' => '',
        'draggable_display_orderby' => __('date',cooks),
        'draggable_display_order' => __('DESC',cooks),
        'draggable_slide_items' => '4',
        'draggable_auto_play' => __('true',cooks),
        'select_cat_type' => '',
        'kaya_slider_cat' => implode(',', $kaya_cat_id),
        'pf_slider_cat' =>  implode(',', $pf_cats_id),
        'draggable_title_color' => '#323232',
        'draggable_content_bg_color' => '#ffffff',
        'hide_lightbox_icon' => '',
        'hide_post_link_icon' => '',
        'hide_price' => ''

      ));
           ?>
       <script type="text/javascript">
      (function($) {
      "use strict";
      $(function() {

      $("#<?php echo $this->get_field_id('select_cat_type') ?>").change(function () {
      $("#<?php echo $this->get_field_id('kaya_slider_cat') ?>").parent().hide();
      $("#<?php echo $this->get_field_id('pf_slider_cat') ?>").parent().hide();
      var selectlayout = $("#<?php echo $this->get_field_id('select_cat_type') ?> option:selected").val(); 
      switch(selectlayout)
        {
          case 'portfolio_category':
           $("#<?php echo $this->get_field_id('pf_slider_cat') ?>").parent().show();
          break;
          case 'slider_category':
           $("#<?php echo $this->get_field_id('kaya_slider_cat') ?>").parent().show();
          break;


        }
      }).change();
     });
  })(jQuery);
    </script>    
      <p>
        <lable for="<?php echo $this->get_field_id('title'); ?>">
        <?php _e('Title',cooks); ?>
        </label>
        <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo $this->get_field_name('title') ?>" />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('title_color'); ?>">
        <?php _e('Title Color',cooks) ?>
        </label>
        <input type="text" name="<?php echo $this->get_field_name('title_color') ?>" id="<?php echo $this->get_field_id('title_color') ?>" class="widefat" value="<?php echo $instance['title_color'] ?>" />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('text_align') ?>">
        <?php _e('Title Position',cooks)?>
        </label>
        <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('text_align') ?>">
          <option value="left" <?php selected('left', $instance['text_align']) ?>>
          <?php esc_html(_e('Title Left',cooks)); ?>
          </option>
          <option value="right" <?php selected('right', $instance['text_align']) ?>>
          <?php esc_html(_e('Title Right',cooks)); ?>
          </option>
          <option value="center" <?php selected('center', $instance['text_align']) ?>>
          <?php esc_html(_e('Title Center',cooks) );?>
          </option>
        </select>
      </p>
      <p>
      <label for="<?php echo $this->get_field_id('select_cat_type') ?>"> <?php _e('Select Slider Category : ',cooks); ?></label>
      <select id="<?php echo $this->get_field_id('select_cat_type') ?>" name="<?php echo $this->get_field_name('select_cat_type') ?>">
       <option value="portfolio_category" <?php selected('portfolio_category', $instance['select_cat_type']) ?>> <?php _e('Portfolio Category',cooks) ?> </option> 
       <option value="slider_category" <?php selected('slider_category',$instance['select_cat_type']) ?>><?php _e('Kaya Slider Category','
       cooks') ?></option>
       </select>
      </p>
         <p>
      <label for="<?php echo $this->get_field_id('pf_slider_cat') ?>">  <?php _e('Enter Portfolio Category IDs : ',cooks) ?>  </label>
          <input type="text" name="<?php echo $this->get_field_name('pf_slider_cat') ?>" id="<?php echo $this->get_field_id('pf_slider_cat') ?>" class="widefat" value="<?php echo $instance['pf_slider_cat'] ?>" />
     <em><strong style="color:green;"><?php _e('Available Categories and IDs : ',cooks); ?> </strong> <?php echo implode(',', $pf_cats_name); ?></em><br />
     <stong><?php _e('Note:',cooks); ?></strong><?php _e('Separate IDs with commas only',cooks); ?>
    </p>
   <p>
      <label for="<?php echo $this->get_field_id('kaya_slider_cat') ?>">   <?php _e('Enter Kaya Slider Category IDs : ',cooks) ?>  </label>
          <input type="text" name="<?php echo $this->get_field_name('kaya_slider_cat') ?>" id="<?php echo $this->get_field_id('kaya_slider_cat') ?>" class="widefat" value="<?php echo $instance['kaya_slider_cat'] ?>" />
      <em><strong style="color:green;"><?php _e('Available Categories and IDs : ',cooks); ?> </strong><?php echo implode(',', $kaya_cat_name); ?></em><br />
      <stong><?php _e('Note:',cooks); ?></strong><?php _e('Separate IDs with commas only',cooks); ?>
    </p>
      <p>
        <label for="<?php echo $this->get_field_id('draggable_slide_items') ?>">
        <?php _e('Portfolio Slide Items',cooks); ?>
        </label>
        <select id="<?php echo $this->get_field_id('draggable_slide_items') ?>" name="<?php echo $this->get_field_name('draggable_slide_items') ?>">
          <option value="1" <?php selected('1', $instance['draggable_slide_items']) ?>>
          <?php esc_html(_e('1 Item',cooks)); ?>
          </option>
          <option value="2" <?php selected('2', $instance['draggable_slide_items']) ?>>
          <?php esc_html(_e('2 Items',cooks) );?>
          </option>
          <option value="3" <?php selected('3', $instance['draggable_slide_items']) ?>>
          <?php esc_html(_e('3 Items',cooks)); ?>
          </option>
          <option value="4" <?php selected('4', $instance['draggable_slide_items']) ?>>
          <?php esc_html(_e('4 Items',cooks) );?>
          </option>
          <option value="5" <?php selected('5', $instance['draggable_slide_items']) ?>>
          <?php esc_html(_e('5 Items',cooks) );?>
          </option>
        </select>
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('draggable_auto_play') ?>">
        <?php _e('Auto Play',cooks)?>
        </label>
        <select id="<?php echo $this->get_field_id('draggable_auto_play') ?>" name="<?php echo $this->get_field_name('draggable_auto_play') ?>">
          <option value="true" <?php selected('true', $instance['draggable_auto_play']) ?>>
          <?php esc_html(_e('True',cooks) );?>
          </option>
          <option value="false" <?php selected('false', $instance['draggable_auto_play']) ?>>
          <?php esc_html(_e('False',cooks)); ?>
          </option>
        </select>
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('draggable_display_orderby') ?>">
        <?php _e('Orderby',cooks)?>
        </label>
        <select id="<?php echo $this->get_field_id('draggable_display_orderby') ?>" name="<?php echo $this->get_field_name('draggable_display_orderby') ?>">
          <option value="date" <?php selected('date', $instance['draggable_display_orderby']) ?>>
          <?php esc_html(_e('Date',cooks)); ?>
          </option>
          <option value="menu_order" <?php selected('menu_order', $instance['draggable_display_orderby']) ?>>
          <?php esc_html(_e('Menu Order',cooks)); ?>
          </option>
          <option value="title" <?php selected('title', $instance['draggable_display_orderby']) ?>>
          <?php esc_html(_e('Title',cooks)); ?>
          </option>
          <option value="rand" <?php selected('rand', $instance['draggable_display_orderby']) ?>>
          <?php esc_html(_e('Random',cooks)); ?>
          </option>
          <option value="author" <?php selected('author', $instance['draggable_display_orderby']) ?>>
          <?php esc_html(_e('Author',cooks)); ?>
          </option>
        </select>
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('draggable_display_order') ?>">
        <?php _e('Order',cooks)?>
        </label>
        <select id="<?php echo $this->get_field_id('draggable_display_order') ?>" name="<?php echo $this->get_field_name('draggable_display_order') ?>">
          <option value="ASC" <?php selected('ASC', $instance['draggable_display_order']) ?>>
          <?php esc_html(_e('Ascending',cooks) );?>
          </option>
          <option value="DESC" <?php selected('DESC', $instance['draggable_display_order']) ?>>
          <?php esc_html(_e('Descending',cooks)); ?>
          </option>
        </select>
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('draggable_img_height'); ?>">
        <?php _e('Image Height (px)',cooks) ?>
        </label>
        <input type="text" name="<?php echo $this->get_field_name('draggable_img_height') ?>" id="<?php echo $this->get_field_id('draggable_img_height') ?>" class="widefat" value="<?php echo $instance['draggable_img_height'] ?>" />
      </p>
      <p>
            <label for="<?php echo $this->get_field_id('draggable_content_bg_color'); ?>"><?php _e('Post Slide Content BG Color',cooks) ?></label>
            <input type="text" name="<?php echo $this->get_field_name('draggable_content_bg_color') ?>" id="<?php echo $this->get_field_id('draggable_content_bg_color') ?>" class="widefat" value="<?php echo $instance['draggable_content_bg_color'] ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('draggable_title_color'); ?>"><?php _e('Post Slide Title Color',cooks) ?></label>
            <input type="text" name="<?php echo $this->get_field_name('draggable_title_color') ?>" id="<?php echo $this->get_field_id('draggable_title_color') ?>" class="widefat" value="<?php echo $instance['draggable_title_color'] ?>" />
        </p>
         <p>
        <label for="<?php echo $this->get_field_id('hide_price') ?>"><?php _e('Disable Price',cooks)?></label>&nbsp;
       <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_price"); ?>" name="<?php echo $this->get_field_name("hide_price"); ?>"<?php checked( (bool) $instance["hide_price"], true ); ?> />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('hide_lightbox_icon') ?>"><?php _e('Disable Lightbox icon',cooks)?></label>&nbsp;
       <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_lightbox_icon"); ?>" name="<?php echo $this->get_field_name("hide_lightbox_icon"); ?>"<?php checked( (bool) $instance["hide_lightbox_icon"], true ); ?> />
      </p>
       <p>
        <label for="<?php echo $this->get_field_id('hide_post_link_icon') ?>"><?php _e('Disable Post Link icon',cooks)?></label>&nbsp;
       <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_post_link_icon"); ?>" name="<?php echo $this->get_field_name("hide_post_link_icon"); ?>"<?php checked( (bool) $instance["hide_post_link_icon"], true ); ?> />
      </p>
       <p>
        <label for="<?php echo $this->get_field_id('hide_slide_content') ?>"><?php _e('Disable Slide Content',cooks)?></label>&nbsp;
       <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_slide_content"); ?>" name="<?php echo $this->get_field_name("hide_slide_content"); ?>"<?php checked( (bool) $instance["hide_slide_content"], true ); ?> />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('Popular_post_display') ?>">
        <?php _e('Popular Posts',cooks)?>
        </label>
        <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("Popular_post_display"); ?>" name="<?php echo $this->get_field_name("Popular_post_display"); ?>"<?php checked( (bool) $instance["Popular_post_display"], true ); ?> />
      </p>
<?php  }



 }

 /**
 * kaya Image boxes
 */

 class cooks_Imageboxes_Widget extends WP_Widget

 {
   function __construct()

   {
     parent::__construct( 'kaya-image-boxes',

        __('Cooks-Image Box (PB)',cooks),
       array('description' => __('Displays image box with title and description',cooks)  )
      );

   }

   function widget( $args, $instance ){

      $instance = wp_parse_args($instance,array(

        'title' => __('Enter Title Here',cooks),
        'link' => 'http://www.google.com',
        'description' => __('Enter Description Here',cooks),
        "image_uri" => '',
        'description_color' => '',
        'title_color' => '#343434',
        'border_color' => '#6E6E6E',
        'imagebox_align' => '',
        'image_width' => '100',
        'image_height' => '100',
        'image_radius' => '0',
        'menu_item_price' => '$20',
        'imagebox_bg_color' => '',
        'readmore_bg_color' => '#cccccc',
        'readmore_text_color' => '#333333',
        'readmore_hover_bg_color' => '#339933',
        'disable_imagebox_link' =>'',
        'readmore_text' => __('Readmore',cooks)
        ));

        echo $args['before_widget'];
       $button_hover =rand(1,100);
        ?>
         
             <style type="text/css">
        #mid_container_wrapper .image-boxes-<?php echo $button_hover; ?> a.readmore:hover{
            background-color:<?php echo $instance['readmore_hover_bg_color']; ?>!important;
            
        }
              </style>
        
           <?php echo '<div class="image-boxes image-boxes-'.$button_hover.' image_box_'.$instance['imagebox_align'].'" style="background-color:'.$instance['imagebox_bg_color'].'">'; ?>
          
                    <div class="figure  align<?php echo $instance['imagebox_align']; ?>">

            <?php if($instance['disable_imagebox_link'] != 'on' ): ?>
               <a href="<?php echo esc_url($instance['link']); ?>" >
                <?php endif; ?>          
          <?php 
              if( $instance['image_uri'] ){
                echo '<img src="'.aq_resize( $instance['image_uri'], $instance['image_width'], $instance['image_height'], true ).'" class="" alt="'.$instance['title'].'"  />';
               }else{
                  echo '<img src="'.get_template_directory_uri().'/images/defult_featured_img.png" style="width:'.$instance['image_width'].'px; height:'.$instance['image_height'].'px;" alt="'.$instance['title'].'" >';
               } 
             ?>
           <?php if( $instance['link'] ){ ?> 
</a> 
<?php } ?>
          </div>
        <?php //endif; ?>
        <?php  echo '<div class="description" style="text-align:'.$instance['imagebox_align'].'">';
             if( $instance['title'] ): echo '<h3 style="color:'.$instance['title_color'].'">'; if( $instance['link'] ){ echo '<a style="color:'.$instance['title_color'].'" href="'.$instance['link'].'">'; }
                 echo $instance['title']; 
             if( $instance['link'] ){ echo '</a>'; } echo '</h3>'; endif;
             if( $instance['menu_item_price'] ):  echo '<span class="menu_item_price">'.$instance['menu_item_price'].'</span><div class="clear"> </div>'; endif;  
            if( $instance['description'] ):  echo '<p style="color:'.$instance['description_color'].'">'.$instance['description'].'</p>'; endif;
           if( $instance['readmore_text'] ): echo '<a href="'.esc_url($instance['link']).'" style="background-color:'.$instance['readmore_bg_color'].'; color:'.$instance['readmore_text_color'].'!important;" class="readmore readmore-1">'.esc_attr($instance['readmore_text']).'</a>'; endif; 
           echo '</div>';?> 
          
           <?php
      echo "</div>";       
    echo $args['after_widget'];

    }

    function form( $instance ){



      $instance = wp_parse_args($instance, array(

        'title' => __('Enter Title Here',cooks),
        'link' => 'http://www.google.com',
        'description' => __('Enter Description Here',cooks),
        "image_uri" => '',
        'description_color' => '',
        'title_color' => '#343434',
        'border_color' => '#6E6E6E',
        'imagebox_align' => '',
        'image_width' => '100',
        'image_height' => '100',
        'image_radius' => '0',
        'menu_item_price' => '$20',
        'imagebox_bg_color' => '',
        'readmore_bg_color' => '#cccccc',
        'readmore_text_color' => '#333333',
        'readmore_hover_bg_color' => '#339933',
        'disable_imagebox_link' =>'',
        'readmore_text' => __('Readmore',cooks)
        ));

        ?>
         <p><?php $i = rand(1,100); ?>
      <img class="custom_media_image_<?php echo $i; ?>" src="<?php if(!empty($instance['image_uri'])){echo $instance['image_uri'];} ?>" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" />
      <input type="text" class="widefat custom_media_url_<?php echo $i; ?>" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo $instance['image_uri']; ?>">
      <input type="button" value="<?php _e( 'Upload Image', 'themename' ); ?>" class="button custom_media_upload_<?php echo $i; ?>" id="custom_media_upload_<?php echo $i; ?>"/>
      <script type="text/javascript">
        jQuery(document).ready( function(){
          jQuery('.custom_media_upload_<?php echo $i; ?>').click(function(e) {
              e.preventDefault();
              var custom_uploader = wp.media({
                  title: 'Image Box Uploading',
                  button: {
                      text: 'Upload Image'
                  },
                  multiple: false  // Set this to true to allow multiple files to be selected
              })
              .on('select', function() {
                  var attachment = custom_uploader.state().get('selection').first().toJSON();
                  jQuery('.custom_media_image_<?php echo $i; ?>').attr('src', attachment.url);
                  jQuery('.custom_media_url_<?php echo $i; ?>').val(attachment.url);
              })
              .open();
          });
          });

      </script>
  </p>
      <p>
        <label for="<?php echo $this->get_field_id('image_width') ?>">
        <?php _e('Image Width (px)',cooks)?>
        </label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id('image_width') ?>" value="<?php echo esc_attr($instance['image_width']) ?>" name="<?php echo $this->get_field_name('image_width') ?>" />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('image_height') ?>">
        <?php _e('Image Height (px)',cooks)?>
        </label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id('image_height') ?>" value="<?php echo esc_attr($instance['image_height']) ?>" name="<?php echo $this->get_field_name('image_height') ?>" />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('image_radius') ?>">
        <?php _e('Image Radius ( % )',cooks)?>
        </label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id('image_radius') ?>" value="<?php echo esc_attr($instance['image_radius']) ?>" name="<?php echo $this->get_field_name('image_radius') ?>" />
        <small><?php _e('Ex:10,20,50',cooks) ?></small>
      </p>
      
      <p>
        <lable for="<?php echo $this->get_field_id('title'); ?>">
        <?php _e('Title',cooks); ?>
        </label>
        <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo esc_attr( $this->get_field_name('title') ) ?>" />
      </p>
      <p>
        <lable for="<?php echo $this->get_field_id('menu_item_price'); ?>">
        <?php _e('Price',cooks); ?>
        </label>
        <input type="text" id="<?php echo $this->get_field_id('menu_item_price') ?>" class="widefat" value="<?php echo esc_attr($instance['menu_item_price']) ?>" name="<?php echo esc_attr( $this->get_field_name('menu_item_price') ) ?>" />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('imagebox_bg_color'); ?>"><?php _e('Imagebox BG Color',cooks) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('imagebox_bg_color') ?>" id="<?php echo $this->get_field_id('imagebox_bg_color') ?>" class="widefat" value="<?php echo $instance['imagebox_bg_color'] ?>" />
     </p>
      <p>
        <label for="<?php echo $this->get_field_id('title_colortitle_color') ?>">
        <?php _e('Title Color',cooks)?>
        </label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id('title_colortitle_color') ?>" value="<?php echo esc_attr($instance['title_color']) ?>" name="<?php echo $this->get_field_name('title_color') ?>" />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('description') ?>">
        <?php _e('Description',cooks)?>
        </label>
        <textarea cols="10" class="widefat" id="<?php echo $this->get_field_id('description') ?>" value="<?php echo esc_attr($instance['description']) ?>" name="<?php echo $this->get_field_name('description') ?>" ><?php echo esc_attr($instance['description']) ?></textarea>
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('description_color') ?>">
        <?php _e('Description Color',cooks)?>
        </label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id('description_color') ?>" value="<?php echo esc_attr($instance['description_color']) ?>" name="<?php echo $this->get_field_name('description_color') ?>" />
      </p>
   
      <label for="<?php echo $this->get_field_id('readmore_text') ?>"> <?php _e('Readmore Button Text',cooks) ?>   
       </label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id('readmore_text') ?>" name="<?php echo $this->get_field_name('readmore_text') ?>" value="<?php echo esc_attr($instance['readmore_text']) ?>" />
  <small>
  <?php _e('<stong>Note: </strong>Keep it empty to not display the readmore button ',cooks) ?>
  </small> </p>
        <p>
        <label for="<?php echo $this->get_field_id('link') ?>"> <?php _e('Destination URL',cooks) ?>    </label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id('link') ?>" value="<?php echo esc_attr($instance['link']) ?>" name="<?php echo $this->get_field_name('link') ?>" />
      </p>
   <p>
        <label for="<?php echo $this->get_field_id('readmore_bg_color'); ?>"><?php _e('Readmore Button BG Color',cooks) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('readmore_bg_color') ?>" id="<?php echo $this->get_field_id('readmore_bg_color') ?>" class="widefat" value="<?php echo $instance['readmore_bg_color'] ?>" />
     </p>
      <p>
        <label for="<?php echo $this->get_field_id('readmore_text_color'); ?>"><?php _e('Readmore Button Text Color',cooks) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('readmore_text_color') ?>" id="<?php echo $this->get_field_id('readmore_text_color') ?>" class="widefat" value="<?php echo $instance['readmore_text_color'] ?>" />
     </p>
     <p>
       <label for="<?php echo $this->get_field_id('readmore_hover_bg_color'); ?>">
          <?php  _e('Readmore Button Hover BG Color',cooks); ?>
         <input id="<?php echo $this->get_field_id('readmore_hover_bg_color'); ?>" name="<?php echo $this->get_field_name('readmore_hover_bg_color'); ?>" type="text" class="widefat" value="<?php echo $instance['readmore_hover_bg_color'] ?>"  />
       </label>
    </p>

  <p>
  <label for="<?php echo $this->get_field_id('disable_imagebox_link') ?>"><?php _e('Disable Image Link',cooks)?></label>&nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_imagebox_link"); ?>" name="<?php echo $this->get_field_name("disable_imagebox_link"); ?>"<?php checked( (bool) $instance["disable_imagebox_link"], true ); ?> />
  </p>
      <p>
        <label for="<?php echo $this->get_field_id('imagebox_align') ?>">
        <?php _e('Image Position',cooks)?>
        </label>
        <select id="<?php echo $this->get_field_id('imagebox_align') ?>" name="<?php echo $this->get_field_name('imagebox_align') ?>">
          <option value="left" <?php selected('left', $instance['imagebox_align']) ?>>
          <?php esc_html(_e('Position Left',cooks) );?>
          </option>
          <option value="right" <?php selected('right', $instance['imagebox_align']) ?>>
          <?php esc_html(_e('Position Right',cooks) );?>
          </option>
          <option value="center" <?php selected('center', $instance['imagebox_align']) ?>>
          <?php esc_html(_e('Position Center',cooks) );?>
          </option>
          <option value="none" <?php selected('none', $instance['imagebox_align']) ?>>
          <?php esc_html(_e('None',cooks) );?>
          </option>
        </select>
      </p>
<?php }

 }

/* Flickr Widget 
-------------------------------------- */
class cooks_Flickr_Widget extends WP_Widget {

  public function __construct() {
    parent::__construct(
      'flickr-widget', // Base ID
      __('Cooks-Flickr (PB)', ''), // Name
      array( 'description' => __( 'Displays flickr image', cooks ), ) // Args
    );

  }
public function widget( $args, $instance ) {

    //echo $args['before_widget'];

  $instance = wp_parse_args( $instance, array(
      'title' => __('Flickr Images',cooks),
      'id' => '',
      'number' => '8',
      ));

// outputs the content of the widget

extract($args); // Make before_widget, etc available.

 $fli_name = empty($instance['title']) ? __('Flickr', cooks) : $instance['title'];

 $fli_id = $instance['id'];

 $fli_number = $instance['number'];

 $unique_id = $args['widget_id'];

 $instance['id'];

echo $before_widget;

echo $before_title . $fli_name . $after_title; ?>
<div id="flickr-widget">
  <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=<?php echo $fli_number; ?>&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=<?php echo $fli_id; ?>"></script>
</div>
<?php echo $after_widget; ?>
<?php }
public function form($instance) {
// Get the options into variables, escaping html characters on the way
  $instance = wp_parse_args( $instance, array(
      'title' => __('Flickr Images',cooks),
      'id' => '',
      'number' => '8',
      ));
?>
<p>
  <label for="<?php echo $this->get_field_id('title'); ?>">
  <?php  _e('Flickr Name',cooks); ?>
  :
  <input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" class="widefat" value="<?php echo $instance['title'] ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('id'); ?>">
  <?php  _e('Flickr ID - ',cooks); ?>
  <a target="_blank" href="http://www.idgettr.com">idGettr</a> ex: 52617155@N08
  <input id="<?php echo $this->get_field_id('id'); ?>" name="<?php echo $this->get_field_name('id'); ?>" type="text" class="widefat" value="<?php echo $instance['id'] ?>"  />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('number'); ?>">
  <?php _e('Number of photos:',cooks); ?>
  <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" class="widefat" value="<?php echo $instance['number'] ?>"  />
  </label>
</p>
<?php

}

}

class cooks_Readmore_Button_Widget extends WP_Widget {
  public function __construct(){
  parent::__construct(
     'Cooks-readmore-button',
    __('cooks - Button (PB) ',cooks),   
    array( 'description' => __('Displays Readmore Butoom where ever you want',cooks),'class' => 'kaya_readmore_widget',
      )
    );
}
  public function widget( $args , $instance){
      $instance = wp_parse_args($instance, array(
          
          'readmore_button_text' => __('Readmore',cooks),
          'readmore_button_link' => 'http://www.google.com',
          'readmore_button_color' => '#e7a802',
          'readmore_button_text_color' => '#ffffff',
          'readmore_button_hover_color' => '#333333',
          'readmore_button_hover_link_color' => '#ffffff',
          'readmore_button_alignment' => __('left',cooks),
          'readmore_button_new_window' => ''

      ));
        echo $args['before_widget']; 
          $button_hover =rand(1,100);
        ?>
         <style type="text/css">
         #mid_container_wrapper .widget_cooks-readmore-button .widget_readmore-<?php echo $button_hover; ?> {
            color: <?php echo $instance['readmore_button_text_color']; ?>!important;
             background: <?php echo $instance['readmore_button_color']; ?>!important;
        }
        #mid_container_wrapper .widget_cooks-readmore-button .widget_readmore-<?php echo $button_hover; ?>:hover {
            background-color: <?php echo $instance['readmore_button_hover_color']; ?>!important;
            color: <?php echo $instance['readmore_button_hover_link_color']; ?>!important;
        }
       
         .widget_readmore-<?php echo $button_hover; ?>.aligncenter{
          display: table!important;
        }
        </style>
        <?php $target_window = ( $instance['readmore_button_new_window'] == 'on' ) ? '_blank' : '_self'; ?>
        <a class="readmore widget_readmore-<?php echo $button_hover; ?> align<?php echo $instance['readmore_button_alignment']; ?>" href="<?php echo $instance['readmore_button_link']; ?>" target="<?php echo $target_window; ?>" style="color:<?php echo $instance['readmore_button_text_color']; ?>;"><?php echo $instance['readmore_button_text']; ?></a>
         <?php   echo '<div class="clear">&nbsp;</div>';
        echo $args['after_widget'];

    }
    public function form($instance){
      $instance = wp_parse_args($instance, array(
          
          'readmore_button_text' => __('Readmore',cooks),
          'readmore_button_link' => 'http://www.google.com',
          'readmore_button_color' => '#e7a802',
          'readmore_button_text_color' => '#ffffff',
          'readmore_button_hover_color' => '#333333',
          'readmore_button_hover_link_color' => '#ffffff',
          'readmore_button_alignment' => __('left',cooks),
          'readmore_button_new_window' => ''
          

      ));?>

      <p>
  <label for="<?php echo $this->get_field_id('readmore_button_text'); ?>">
  <?php  _e('Button Text',cooks); ?>
  <input id="<?php echo $this->get_field_id('readmore_button_text'); ?>" name="<?php echo $this->get_field_name('readmore_button_text'); ?>" type="text" class="widefat" value="<?php echo $instance['readmore_button_text'] ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('readmore_button_link'); ?>">
  <?php  _e('Destination URL',cooks); ?>
  <input id="<?php echo $this->get_field_id('readmore_button_link'); ?>" name="<?php echo $this->get_field_name('readmore_button_link'); ?>" type="text" class="widefat" value="<?php echo $instance['readmore_button_link'] ?>"  />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('readmore_button_color'); ?>">
  <?php _e('Button Background Color',cooks); ?>
  <input id="<?php echo $this->get_field_id('readmore_button_color'); ?>" name="<?php echo $this->get_field_name('readmore_button_color'); ?>" type="text" class="widefat" value="<?php echo $instance['readmore_button_color'] ?>"  />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('readmore_button_text_color'); ?>">
  <?php  _e('Button Text Color',cooks); ?>
  <input id="<?php echo $this->get_field_id('readmore_button_text_color'); ?>" name="<?php echo $this->get_field_name('readmore_button_text_color'); ?>" type="text" class="widefat" value="<?php echo $instance['readmore_button_text_color'] ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('readmore_button_hover_color'); ?>">
  <?php  _e('Button Hover BG Color',cooks); ?>
  <input id="<?php echo $this->get_field_id('readmore_button_hover_color'); ?>" name="<?php echo $this->get_field_name('readmore_button_hover_color'); ?>" type="text" class="widefat" value="<?php echo $instance['readmore_button_hover_color'] ?>"  />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('readmore_button_hover_link_color'); ?>">
  <?php _e('Button Hover Text Color',cooks); ?>
  <input id="<?php echo $this->get_field_id('readmore_button_hover_link_color'); ?>" name="<?php echo $this->get_field_name('readmore_button_hover_link_color'); ?>" type="text" class="widefat" value="<?php echo $instance['readmore_button_hover_link_color'] ?>"  />
  </label>
</p> 
<p>
        <label for="<?php echo $this->get_field_id('readmore_button_alignment') ?>">  <?php _e('Button Alignment',cooks) ?> </label>
        <select id="<?php echo $this->get_field_id('readmore_button_alignment') ?>" name="<?php echo $this->get_field_name('readmore_button_alignment') ?>">
          <option value="left" <?php selected('left', $instance['readmore_button_alignment']) ?>> 
            <?php esc_html(_e('Left', cooks)); ?> </option>
          <option value="right" <?php selected('right', $instance['readmore_button_alignment']) ?>> 
            <?php esc_html(_e('Right', cooks) );?> </option>
          <option value="center" <?php selected('center', $instance['readmore_button_alignment']) ?>>
           <?php esc_html(_e('Center', cooks) );?> </option>
        </select>
      </p>
 <p>
        <label for="<?php echo $this->get_field_id('readmore_button_new_window') ?>"> <?php _e('Open In New Window',cooks) ?> </label>
        <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("readmore_button_new_window"); ?>" name="<?php echo $this->get_field_name("readmore_button_new_window"); ?>"<?php checked( (bool) $instance["readmore_button_new_window"], true ); ?> />
      </p>    
<?php }
}
// Info Boxes
class cooks_Info_Boxes extends WP_Widget{
  public function __construct(){
    parent::__construct(
        'info-boxes',
          __('Cooks-Info Boxes (PB)', cooks), // Name
        array(
            'description' => __('Info boxes',cooks) , 'class' => 'cooks_class'
          )
      );
} public function widget( $args, $instance){
        $instance= wp_parse_args($instance, array(
              'info_box_type' => __('success',cooks),
              'info_box_content' => ''
          ));
        echo $args['before_widget'];
          echo '<div class="info_box '.$instance['info_box_type'].'">';
              echo $instance['info_box_content'];
              echo '<img src="'.plugins_url( 'images/'.$instance['info_box_type'].'_btn.png' , __FILE__ ).'" class="delete">';
          echo '</div>';
        echo $args['after_widget'];

    }
    public function form($instance){
        $instance= wp_parse_args($instance, array(
              'info_box_type' => __('success',cooks),
              'info_box_content' => ''
          ));
      ?>

      <p> <label for="<?php echo $this->get_field_id('info_box_type') ?>"><?php _e('Info Box Type',cooks) ?></label>
        <select id="<?php echo $this->get_field_id('info_box_type') ?>" name="<?php echo $this->get_field_name('info_box_type') ?>">
          <option value="success" id="<?php echo $this->get_field_id('info_box_type') ?>" <?php selected( 'success',$instance['info_box_type'] ) ?> >
            <?php esc_html(_e('Success', cooks) );?></option>
          <option value="info" id="<?php echo $this->get_field_id('info_box_type') ?>" <?php selected( 'info',$instance['info_box_type'] ) ?> >
            <?php esc_html(_e('Info', cooks)); ?></option>
          <option value="warning" id="<?php echo $this->get_field_id('info_box_type') ?>" <?php selected( 'warning',$instance['info_box_type'] ) ?> >
            <?php esc_html(_e('Warning', cooks)); ?></option>
          <option value="error" id="<?php echo $this->get_field_id('info_box_type') ?>" <?php selected( 'error',$instance['info_box_type'] ) ?> >
            <?php esc_html(_e('Error', cooks) );?></option>      
        </select>
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('info_box_content') ?>"><?php _e('Info Box Content',cooks) ?></lable>
         <textarea type="text" id="<?php echo $this->get_field_id('info_box_content') ?>" class="widefat" name="<?php echo $this->get_field_name('info_box_content') ?>" value = "<?php echo $instance['info_box_content'] ?>" > <?php echo $instance['info_box_content'] ?></textarea>
      </p>
      <?php
    }
  }
//Testimonial
  class cooks_Testimonial_Widget extends WP_Widget{
   public function __construct(){
   parent::__construct(  'kaya-testimonials',
      __('Cooks-Testimonial (PB)',cooks),
      array( 'description' => __('Displays testimonial boxes',cooks), 'class' => 'kaya_testimonial_widget' )
    );
    }
    public function widget( $args , $instance ){
        $instance = wp_parse_args($instance, array(
              'title' => __('Client Name <span>Designation</span>',cooks),
              'img_url' => '#',
              'description' => __('Add Your Testimonial description', cooks),
              'link' => '#',
              "testimonial_img" => '',
              'tm_bg_color' => '#ffffff',
              'tm_client_name_color' => '#333',
              'tm_description_color' => '#555'
             )); 
                $tm_rand = rand(1,20);
             ?>
            <style>
            .testimonial-<?php echo $tm_rand; ?> .description:before{
              border-right: 12px solid <?php echo $instance['tm_bg_color']; ?>!important;
            }
            </style>
          <?php
          echo $args['before_widget'];
            echo '<div class="testimonial_wrapper testimonial-'.$tm_rand.'" >';
              echo '<a href="'.$instance['link'].'" target="_blank">';
                   if( $instance['testimonial_img'] ){
                  echo '<img src="'.aq_resize( $instance['testimonial_img'], '75', '75', true ).'" class="alignleft testimonial_img" alt="'.$instance['title'].'"  />';
                  }else{     ?> 
                  <img src="<?php echo plugins_url( 'images/defult_featured_img.png' , __FILE__ ); ?>" style="width:75px; height:75px;" class="alignleft testimonial_img" width="75" height="75" alt=" "  />
               <?php    } ?>

                   <?php echo '</a>';
                // endif;
               echo '<div class="description" style="background-color:'.$instance['tm_bg_color'].'">';
                if( $instance['description']): echo '<p style="color:'.$instance['tm_description_color'].'">'. $instance['description'].'</p>'; endif;
                if( $instance['title'] ): echo '<h5 style="color:'.$instance['tm_client_name_color'].'">'.$instance['title'].'</h5>'; endif;
              echo '</div>';
          echo '</div>';
          echo $args['after_widget'];

    }
    public function form( $instance ){

        $instance = wp_parse_args( $instance, array(
              'title' => __('Client Name <span>Designation</span>',cooks),
              'img_url' => '#',
              'description' => __('Add Your Testimonial description', cooks),
              'link' => '#',
              "testimonial_img" => '',
              'tm_bg_color' => '#ffffff',
              'tm_client_name_color' => '#333',
              'tm_description_color' => '#555'
        ) );
        ?>
      <p><?php $i = rand(1,100); ?>
      <img class="custom_media_image_<?php echo $i; ?>" src="<?php if(!empty($instance['testimonial_img'])){echo $instance['testimonial_img'];} ?>" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" />
      <input type="text" class="widefat custom_media_url_<?php echo $i; ?>" name="<?php echo $this->get_field_name('testimonial_img'); ?>" id="<?php echo $this->get_field_id('testimonial_img'); ?>" value="<?php echo $instance['testimonial_img']; ?>">
      <input type="button" value="<?php _e( 'Upload Testimonial Image', 'themename' ); ?>" class="button custom_media_upload_<?php echo $i; ?>" id="custom_media_upload_<?php echo $i; ?>"/>
      <script type="text/javascript">
        jQuery(document).ready( function(){
          jQuery('.custom_media_upload_<?php echo $i; ?>').click(function(e) {
              e.preventDefault();
              var custom_uploader = wp.media({
                  title: 'Testimonial Image',
                  button: {
                      text: 'Upload Testimonial Image'
                  },
                  multiple: false  // Set this to true to allow multiple files to be selected
              })
              .on('select', function() {
                  var attachment = custom_uploader.state().get('selection').first().toJSON();
                  jQuery('.custom_media_image_<?php echo $i; ?>').attr('src', attachment.url);
                  jQuery('.custom_media_url_<?php echo $i; ?>').val(attachment.url);
              })
              .open();
          });
          });

      </script>
  </p>
       <p> <label for="<?php echo $this->get_field_id('link') ?>"><?php _e('Image Link',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('link') ?>" id="<?php echo $this->get_field_id('link') ?>" class="widefat" value="<?php echo $instance['link'] ?>"  />
        <small><?php _e('Ex: http://www.google.com',cooks); ?></small>
    </p>
    
     <p>
        <label for="<?php echo $this->get_field_id('description') ?>"><?php _e('Description',cooks); ?></label>
         <textarea cols="40" name="<?php echo $this->get_field_name('description') ?>" id="<?php echo $this->get_field_id('description') ?>" value="<?php echo $instance['description'] ?>" class="widefat" ><?php echo $instance['description'] ?></textarea>
      </p>
     <p>
        <label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Client Name',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('title') ?>" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo $instance['title'] ?>" placeholder="Jhon Deo" />
     </p>
       <p>
        <label for="<?php echo $this->get_field_id('tm_bg_color') ?>"><?php _e('Background Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tm_bg_color') ?>" id="<?php echo $this->get_field_id('tm_bg_color') ?>" class="widefat" value="<?php echo $instance['tm_bg_color'] ?>" />
     </p>
       <p>
        <label for="<?php echo $this->get_field_id('tm_description_color') ?>"><?php _e('Description Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tm_description_color') ?>" id="<?php echo $this->get_field_id('tm_description_color') ?>" class="widefat" value="<?php echo $instance['tm_description_color'] ?>"  />
     </p>
       <p>
        <label for="<?php echo $this->get_field_id('tm_client_name_color') ?>"><?php _e('Client Name Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tm_client_name_color') ?>" id="<?php echo $this->get_field_id('tm_client_name_color') ?>" class="widefat" value="<?php echo $instance['tm_client_name_color'] ?>" />
     </p>
 
     <?php  }
 }
 // Toggle Tabs And Accordion
 class cooks_Toggle_Tabs_Accordion extends WP_Widget{
public function __construct(){
  parent::__construct(
    'toggle-tabs-accordion',
    __('cooks - Toggle Tabs',cooks),
    array('description' => __('Add Toggle tabs and Accordion widge',cooks))
    );
}
public function widget($args, $instance){
  $instance = wp_parse_args($instance, array(
      'title' => '',
      'select_type' => '',
      'select_tabs_type' => __('horizontal',cooks),
      'tabs_acordion_order' => '',
      'tabs_acordion_orderby' => '',
      'taba_accordion_cat' => '',
      'limit' => '',
      'tabs_bg_color' => '#ffffff',
      'tabs_content_bg_color' => '#eee',
      'tabs_content_color' => '#666',
      'tabs_title_color' => '#343434',
      'tabs_border_color' => '#f5f5f5',
      'tabs_content_link_color' => '#343434'
    ));
  // Accordion Script
    $tabs_rand_class = rand(1,100);
    $toggle_rand_class = rand(1,100);
    ?>
    <style>
    .accordion > div a, .toggle_content .block a, .tabDetails a{
      color:<?php echo $instance['tabs_content_link_color'] ?>;
    }
    .tabs-<?php echo $tabs_rand_class; ?>.vertical_tabs .ui-tabs-active a, .tabs-<?php echo $tabs_rand_class; ?>.horizontal_tabs .ui-tabs-active a{
      background-color: <?php echo $instance['tabs_content_bg_color'] ?>!important;
    }
    .tabs-<?php echo $tabs_rand_class; ?>.vertical_tabs .tabDetails p, .tabs-<?php echo $tabs_rand_class; ?>.horizontal_tabs .tabDetails  p{
      color: <?php echo $instance['tabs_content_color'] ?>!important;
    }
    .toggle-<?php echo $toggle_rand_class; ?> .toggle_container_wrapper p{
      color: <?php echo $instance['tabs_content_color'] ?>!important;
    }
    </style>
    <?php
  $accordion_rand = rand(1,100);
  $tabs_rand = rand(1,100);
      if( $instance['select_type'] == 'accordion' ){
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
          $( "#accordion<?php echo $accordion_rand; ?>" ).accordion({
            autoHeight: true,
            collapsible: false,
             heightStyle: "content"
          });

         });
    </script>
        <?php  } // Tabs Script ?>
    <?php    if( $instance['select_type'] == 'tabs' ){ ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
          $("#tabid-<?php echo $tabs_rand; ?>").tabs().addClass( "<?php echo $instance['select_tabs_type']; ?>_tabs" );
          //$( "#tabs li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
         });
    </script>
    <?php
  } ?>
  <?php  // Switch case in tabs type and add classes
  echo $args['before_widget'];
  switch ($instance['select_type']) {
    case 'accordion':
      $ids='accordion'.$accordion_rand.'';
      $class = '';
      break;
    case 'tabs':
      $ids='tabid-'.$tabs_rand.'';
      $class = 'tabContaier tabs-'.$tabs_rand_class.'';
      break;
    case 'toggle':
      $ids='';
      $class = 'toggle-'.$toggle_rand_class.'';
      break;
    default:
      $ids='';
       $class = '';
      break;
  }
    
    echo '<div class="'.$instance['select_type'].'_wrapper '.$instance['select_type'].' '.$class.' " id="'.$ids.'">';
    // Adding ul when tabs active 
    if ($instance['select_type'] == 'tabs') { echo '<ul class="tabContaier">'; }

 $array_val = ( !empty( $instance['taba_accordion_cat'] )) ? explode(',', $instance['taba_accordion_cat']) : '';
              if( $array_val ) {
                $loop = new WP_Query(array( 'post_type' => 'toogletabs',   'orderby' => $instance['tabs_acordion_orderby'], 'posts_per_page' =>$instance['limit'],'order' => $instance['tabs_acordion_order'],  'tax_query' => array('relation' => 'AND', array( 'taxonomy' => 'toggletabs_category',   'field' => 'id', 'terms' => $array_val  ) )));
                }else{
                   $loop = new WP_Query(array('post_type' => 'toogletabs' , 'taxonomy' => 'toggletabs_category', 'term' => $instance['taba_accordion_cat'], 'orderby' => $instance['tabs_acordion_orderby'], 'posts_per_page' =>$instance['limit'],'order' => $instance['tabs_acordion_order'] ));
                }

  if( $loop->have_posts() ) : while( $loop->have_posts() ) : $loop->the_post(); 
    if( $instance['select_type'] == 'accordion' ){ // Accordion ?>
      <strong style="background-color:<?php echo $instance['tabs_bg_color']; ?>; color:<?php echo $instance['tabs_title_color']; ?>; border:1px solid <?php echo $instance['tabs_border_color'] ?>;"><?php echo the_title(); ?></strong>
      <div style="background-color:<?php echo $instance['tabs_content_bg_color']; ?>; color:<?php echo $instance['tabs_content_color']; ?>; border:1px solid <?php echo $instance['tabs_border_color'] ?>;"> <?php echo get_the_content(); ?> </div> 
    <?php } 
      elseif( $instance['select_type'] == 'toggle' ){ // Toggle ?>
        <div class="toggle_container_wrapper"><strong class="trigger" style="background-color:<?php echo $instance['tabs_bg_color']; ?>; color:<?php echo $instance['tabs_title_color']; ?>; border:1px solid <?php echo $instance['tabs_border_color'] ?>;" ><?php echo the_title(); ?></strong><div class="toggle_content"><div class="block" style="background-color:<?php echo $instance['tabs_content_bg_color']; ?>; color:<?php echo $instance['tabs_content_color']; ?>; border:1px solid <?php echo $instance['tabs_border_color'] ?>;"><?php echo the_content(); ?></div></div></div>

     <?php }
      elseif ($instance['select_type'] == 'tabs') { // Tabs
       $string = mb_strtolower( preg_replace("/[\s_]/", "-", get_the_title()));
        echo '<li><a style="background-color:'.$instance['tabs_bg_color'].'; color:'.$instance['tabs_title_color'].'!important; border:1px solid'.$instance['tabs_border_color'].';" href="#'.trim($string).'">'.get_the_title().'</a></li>';
      }

     ?>
  <?php endwhile;
  wp_reset_query();
  endif;
     if ($instance['select_type'] == 'tabs') { echo '</ul>'; // End Tabs UL
     if( $loop->have_posts() ) : while( $loop->have_posts() ) : $loop->the_post(); // Tabs Content loop 
       $string = mb_strtolower( preg_replace("/[\s_]/", "-", get_the_title())); ?>
       <div id="<?php echo trim($string); ?>">
           <div class="tabDetails" style="background-color:<?php echo $instance['tabs_content_bg_color']; ?>; color:<?php echo $instance['tabs_content_color']; ?>; border:1px solid <?php echo $instance['tabs_border_color'] ?>;"><?php the_content(); ?></div>
      </div>
     <?php endwhile;
     wp_reset_query();
     endif; // End Tabs Loop
     }
  echo  '</div>';
  echo $args['after_widget'];
}
// Form
public function form($instance){
  $tabs_terms=  get_terms('toggletabs_category','');
        if( $tabs_terms ){
          foreach ($tabs_terms as $tabs_term) { 
            $tab_cat_ids[] = $tabs_term->term_id;
             $tab_cats_name[] = $tabs_term->name.' - '.$tabs_term->term_id;
          }
        }else{ $tab_cats_name[] = ''; $tab_cat_ids[] = ''; }
    $instance = wp_parse_args($instance, array(
      'title' => '',
      'select_type' => '',
      'select_tabs_type' => __('horizontal',cooks),
      'tabs_acordion_order' => '',
      'tabs_acordion_orderby' => '',
      'taba_accordion_cat' => implode(',', $tab_cat_ids),
      'limit' => '',
      'tabs_bg_color' => '#ffffff',
      'tabs_content_bg_color' => '#eee',
      'tabs_content_color' => '#666',
      'tabs_title_color' => '#343434',
      'tabs_border_color' => '#f5f5f5',
      'tabs_content_link_color' => '#343434'
    )); ?>
  <script type="text/javascript">
      (function($) {
      "use strict";
      $(function() {

      $("#<?php echo $this->get_field_id('select_type') ?>").change(function () {
      $("#<?php echo $this->get_field_id('select_tabs_type') ?>").parent().hide();
      var selectlayout = $("#<?php echo $this->get_field_id('select_type') ?> option:selected").val(); 
      switch(selectlayout)
        {
          case 'tabs':
           $("#<?php echo $this->get_field_id('select_tabs_type') ?>").parent().show();
          break;      
        }
      }).change();
     });
  })(jQuery);
    </script>
    <p> <label for="<?php echo $this->get_field_id('select_type') ?>"><?php _e('Select Type',cooks) ?></label>
        <select id="<?php echo $this->get_field_id('select_type') ?>" name="<?php echo $this->get_field_name('select_type') ?>">
          <option value="accordion" id="<?php echo $this->get_field_id('select_type') ?>" <?php selected( 'accordion',$instance['select_type'] ) ?> >
            <?php esc_html(_e('Accordion', cooks)); ?></option>
          <option value="tabs" id="<?php echo $this->get_field_id('select_type') ?>" <?php selected( 'tabs',$instance['select_type'] ) ?> >
            <?php esc_html(_e('Tabs', cooks)); ?></option>
          <option value="toggle" id="<?php echo $this->get_field_id('select_type') ?>" <?php selected( 'toggle',$instance['select_type'] ) ?> >
            <?php esc_html(_e('Toggle ', cooks) );?></option>
              
        </select>
      </p>
      <p> <label for="<?php echo $this->get_field_id('select_tabs_type') ?>"><?php _e('Select Tabs Type',cooks) ?></label>
        <select id="<?php echo $this->get_field_id('select_tabs_type') ?>" name="<?php echo $this->get_field_name('select_tabs_type') ?>">
          <option value="horizontal" id="<?php echo $this->get_field_id('select_tabs_type') ?>" <?php selected( 'horizontal',$instance['select_tabs_type'] ) ?> >
            <?php esc_html(_e('Horizontal Tabs', cooks)); ?></option>
          <option value="vertical" id="<?php echo $this->get_field_id('select_tabs_type') ?>" <?php selected( 'vertical',$instance['select_tabs_type'] ) ?> >
            <?php esc_html(_e('Vertical Tabs', cooks)); ?></option>
        </select>
      </p>
      <p>
 
  <p>
  <label for="<?php echo $this->get_field_id('taba_accordion_cat') ?>"> <?php _e('Enter Category IDs : ',cooks) ?> </label>
 <input type="text" name="<?php echo $this->get_field_name('taba_accordion_cat') ?>" id="<?php echo $this->get_field_id('taba_accordion_cat') ?>" class="widefat" value="<?php echo $instance['taba_accordion_cat'] ?>" />
  <em><strong style="color:green;"><?php _e('Available Categories and IDs : ',cooks); ?> </strong> <?php echo implode(', ', $tab_cats_name); ?></em><br />
  <stong><?php _e('Note:',cooks); ?></strong><?php _e('Separate IDs with commas only',cooks); ?>
</p>


           <p>
      <label for="<?php echo $this->get_field_id('tabs_acordion_orderby') ?>"><?php _e('Orderby',cooks)?></label>
        <select id="<?php echo $this->get_field_id('tabs_acordion_orderby') ?>" name="<?php echo $this->get_field_name('tabs_acordion_orderby') ?>">
        <option value="date" <?php selected('date', $instance['tabs_acordion_orderby']) ?>>
          <?php esc_html(_e('Date',cooks) );?></option>
       <option value="menu_order" <?php selected('menu_order', $instance['tabs_acordion_orderby']) ?>>
        <?php esc_html(_e('Menu Order',cooks)); ?></option>
        <option value="title" <?php selected('title', $instance['tabs_acordion_orderby']) ?>>
          <?php esc_html(_e('Title',cooks) );?></option>
        <option value="rand" <?php selected('rand', $instance['tabs_acordion_orderby']) ?>>
          <?php esc_html(_e('Random',cooks));?></option>
        <option value="author" <?php selected('author', $instance['tabs_acordion_orderby']) ?>>
          <?php esc_html(_e('Author',cooks)); ?></option>
      </select>
        </p>
       <p>
      <label for="<?php echo $this->get_field_id('tabs_acordion_order') ?>"><?php _e('Order',cooks)?></label>
        <select id="<?php echo $this->get_field_id('tabs_acordion_order') ?>" name="<?php echo $this->get_field_name('tabs_acordion_order') ?>">
        <option value="ASC" <?php selected('ASC', $instance['tabs_acordion_order']) ?>>
          <?php esc_html(_e('Ascending',cooks) );?></option>
       <option value="DESC" <?php selected('DESC', $instance['tabs_acordion_order']) ?>>
        <?php esc_html(_e('Descending',cooks)); ?></option>
        </select>
        </p> 
      <p>
        <label for="<?php echo $this->get_field_id('limit') ?>"><?php _e('Limit',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('limit') ?>" id="<?php echo $this->get_field_id('limit') ?>"  value="<?php echo $instance['limit'] ?>" />
     </p>
     <p>
        <label for="<?php echo $this->get_field_id('tabs_bg_color') ?>"><?php _e('Tabs Bg Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tabs_bg_color') ?>" id="<?php echo $this->get_field_id('tabs_bg_color') ?>"  value="<?php echo $instance['tabs_bg_color'] ?>" />
     </p>
     <p>
        <label for="<?php echo $this->get_field_id('tabs_title_color') ?>"><?php _e('Tabs Title Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tabs_title_color') ?>" id="<?php echo $this->get_field_id('tabs_title_color') ?>"  value="<?php echo $instance['tabs_title_color'] ?>" />
     </p>
     <p>
        <label for="<?php echo $this->get_field_id('tabs_content_bg_color') ?>"><?php _e('Tabs Content BG Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tabs_content_bg_color') ?>" id="<?php echo $this->get_field_id('tabs_content_bg_color') ?>"  value="<?php echo $instance['tabs_content_bg_color'] ?>" />
     </p>
     <p>
        <label for="<?php echo $this->get_field_id('tabs_content_color') ?>"><?php _e('Tabs Content Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tabs_content_color') ?>" id="<?php echo $this->get_field_id('tabs_content_color') ?>"  value="<?php echo $instance['tabs_content_color'] ?>" />
     </p>
     <p>
        <label for="<?php echo $this->get_field_id('tabs_content_link_color') ?>"><?php _e('Tabs Content Link Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tabs_content_link_color') ?>" id="<?php echo $this->get_field_id('tabs_content_link_color') ?>"  value="<?php echo $instance['tabs_content_link_color'] ?>" />
     </p>
      <p>
        <label for="<?php echo $this->get_field_id('tabs_border_color') ?>"><?php _e('Tabs Border Color',cooks); ?></label>
        <input type="text" name="<?php echo $this->get_field_name('tabs_border_color') ?>" id="<?php echo $this->get_field_id('tabs_border_color') ?>"  value="<?php echo $instance['tabs_border_color'] ?>" />
     </p>
<?php 
}
 }
 // Pricing Table
class cooks_Pricing_Table extends WP_Widget{
  public function __construct(){
    parent::__construct(
      'Cooks-pricing-table',
      __('Cooks - Pricing Table',cooks),
      array('description' => __('Pricing Table ',cooks))
      );
  }
  public function widget($args, $instance){
      $instance = wp_parse_args($instance, array(
          'pricing_content' => '<ul>
                                    <li>Price Text-1</li>
                                    <li>Price Text-2</li>
                                </ul>',
          'pricing_title' => __('Price Title',cooks),
          'price' => '$45',
          'price_description' => __('Per Month',cooks),
          'button_text' => __('Signup',cooks),
          'button_link' => '#',
          'pricing_bg_color' => '#FF9D01',
          'pricing_text_color' => '#333333',
          'pricing_content_li_odd_bg' => '#F8F7DC ',
          'pricing_content_li_odd_color' => '#333333',
          'pricing_content_li_even_bg' => '#ffffff',
          'pricing_content_li_even_color' => '#333333',       
        ));
      $li_rand_color = rand(1,100); ?>
        <style>
        .even-odd-li-<?php echo $li_rand_color; ?> li:nth-child(odd){
              background-color: <?php echo $instance['pricing_content_li_odd_bg'] ?>;
              color: <?php echo $instance['pricing_content_li_odd_color'] ?>;
        }
        .even-odd-li-<?php echo $li_rand_color; ?> li:nth-child(even){
              background-color: <?php echo $instance['pricing_content_li_even_bg'] ?>;
              color: <?php echo $instance['pricing_content_li_even_color'] ?>;
        }
        </style>
      <?php echo $args['before_widget'];
       // echo 'testing pricing table content'; 
        echo '<div class="pricing_table">';
            if( $instance['pricing_title'] ): 
              echo '<div class="pricing_header" style="background-color:'.$instance['pricing_bg_color'].';">';
                echo '<h3><strong style="color:'.$instance['pricing_text_color'].';">'.$instance['pricing_title'] .'</strong></h3>';
              echo '</div>'; 
            endif; 
            if( $instance['price'] || $instance['price_description'] ):
              echo '<div class="price" style="background-color:'.$instance['pricing_bg_color'].';">';
                if( $instance['price'] ): echo '<h1 style="color:'.$instance['pricing_text_color'].';">'.$instance['price'].'</h1>'; endif;
                if( $instance['price_description'] ): echo '<em style="color:'.$instance['pricing_text_color'].';">'.$instance['price_description'].'</em>'; endif;
              echo '</div>'; 
            endif;
            if( $instance['pricing_content'] ):
                echo '<div class="pricing_content even-odd-li-'.$li_rand_color.'">';
                  echo $instance['pricing_content']; 
                echo '</div>';
            endif;    
            if( $instance['button_text'] ):
              echo '<div class="pricing_footer" style="background-color:'.$instance['pricing_bg_color'].';"><a class="read_more" href="'.$instance['button_link'].'">'.$instance['button_text'].'</a></div>';
            endif;
          echo '</div>';
          echo $args['after_widget'];
  }
  public function form($instance){
         $instance = wp_parse_args($instance, array(
          'pricing_content' => '<ul><li>Price List-1</li><li>Price List-2</li></ul>',
          'pricing_title' => __('Price Title',cooks),
          'price' => '$45',
          'price_description' => __('Per Month',cooks),
          'button_text' => __('Signup',cooks),
          'button_link' => '#',
          'pricing_bg_color' => '#FF9D01',
          'pricing_text_color' => '#333333',
          'pricing_content_li_odd_bg' => '#F8F7DC ',
          'pricing_content_li_odd_color' => '#333333',
          'pricing_content_li_even_bg' => '#ffffff',
          'pricing_content_li_even_color' => '#333333',

        )); ?>
    <p>
      <label for="<?php echo $this->get_field_id('pricing_title') ?>"><?php _e('Pricing Title',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('pricing_title') ?>" name="<?php echo $this->get_field_name('pricing_title') ?>" value="<?php echo esc_attr($instance['pricing_title']) ?>">
      <small><?php _e('Ex:Basic, Premium, Standard',cooks) ?></small>     
    </p>  
    <p>
      <label for="<?php echo $this->get_field_id('price') ?>"><?php _e('Price') ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('price') ?>" name="<?php echo $this->get_field_name('price') ?>" value="<?php echo esc_attr($instance['price']) ?>"> 
      <small><?php _e('Ex:$45, $61.5',cooks) ?></small>     
    </p> 
    <p>
      <label for="<?php echo $this->get_field_id('price_description') ?>"><?php _e('Price Description',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('price_description') ?>" name="<?php echo $this->get_field_name('price_description') ?>" value="<?php echo esc_attr($instance['price_description']) ?>">
      <small><?php _e('Ex:Per Month, Per Year',cooks) ?></small>    
    </p>     
    <p>
      <label for="<?php echo $this->get_field_id('pricing_content') ?>"><?php _e('Pricing Content',cooks) ?></label>
      <textarea cols="10" class="widefat" id="<?php echo $this->get_field_id('pricing_content') ?>" value="<?php echo esc_attr($instance['pricing_content']) ?>" name="<?php echo $this->get_field_name('pricing_content') ?>" ><?php echo esc_attr($instance['pricing_content']) ?></textarea>
      <small><?php _e('Note: Pricing content add ul li only',cooks) ?></small>
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('button_text') ?>"><?php _e('Signup Button Text',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('button_text') ?>" name="<?php echo $this->get_field_name('button_text') ?>" value="<?php echo esc_attr($instance['button_text']) ?>">    
      <small><?php _e('Ex: Signup',cooks) ?></small>  
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('button_link') ?>"><?php _e('Signup Button Link',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('button_link') ?>" name="<?php echo $this->get_field_name('button_link') ?>" value="<?php echo esc_attr($instance['button_link']) ?>">
      <small><?php _e('Ex: http://www.google.com',cooks) ?></small>     
    </p>  
    <p>
      <label for="<?php echo $this->get_field_id('pricing_bg_color') ?>"><?php _e('Pricing Box BG Color',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('pricing_bg_color') ?>" name="<?php echo $this->get_field_name('pricing_bg_color') ?>" value="<?php echo esc_attr($instance['pricing_bg_color']) ?>">    
      <small><?php _e('Ex: #FF9D01',cooks) ?></small>  
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('pricing_text_color') ?>"><?php _e('Pricing Box Text Color',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('pricing_text_color') ?>" name="<?php echo $this->get_field_name('pricing_text_color') ?>" value="<?php echo esc_attr($instance['pricing_text_color']) ?>">
      <small><?php _e('Ex: #ffffff',cooks) ?></small>     
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('pricing_content_li_odd_bg') ?>"><?php _e('Price Content Odd BG Color',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('pricing_content_li_odd_
  bg') ?>" name="<?php echo $this->get_field_name('pricing_content_li_odd_bg') ?>" value="<?php echo esc_attr($instance['pricing_content_li_odd_bg']) ?>">    
      <small><?php _e('Ex: #F8F7DC ',cooks) ?></small>  
    </p>
        <p>
      <label for="<?php echo $this->get_field_id('pricing_content_li_odd_color') ?>"><?php _e('Price Content Odd Text Color',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('pricing_content_li_odd_color') ?>" name="<?php echo $this->get_field_name('pricing_content_li_odd_color') ?>" value="<?php echo esc_attr($instance['pricing_content_li_odd_color']) ?>">    
      <small><?php _e('Ex: #333333 ',cooks) ?></small>  
    </p>
        <p>
      <label for="<?php echo $this->get_field_id('pricing_content_li_even_bg') ?>"><?php _e('Price Content Even BG Color',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('pricing_content_li_even_bg') ?>" name="<?php echo $this->get_field_name('pricing_content_li_even_bg') ?>" value="<?php echo esc_attr($instance['pricing_content_li_even_bg']) ?>">    
      <small><?php _e('Ex: #ffffff ',cooks) ?></small>  
    </p>
        <p>
      <label for="<?php echo $this->get_field_id('pricing_content_li_even_color') ?>"><?php _e('Price Content Even Text Color',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('pricing_content_li_even_color') ?>" name="<?php echo $this->get_field_name('pricing_content_li_even_color') ?>" value="<?php echo esc_attr($instance['pricing_content_li_even_color']) ?>">    
      <small><?php _e('Ex: #333333 ',cooks) ?></small>  
    </p>


  <?php }
}
class cooks_Twitter_Widget extends WP_Widget {
  public function __construct(){
    parent::__construct(
      'Cooks-twitter',
      __('cooks - Twitter',cooks),
      array('description' => __('Dsiplay latest tweets',cooks))
      );
  }
  function widget($args, $instance)
  {
   
    $instance = wp_parse_args($instance, array(
          'title' => '',
          'twitter_username' => '', 
          'count' => 3, 
          'consumer_key' => '',
          'access_token' => '',
          'consumer_secret' => '', 
          'access_token' => '', 
          'access_token_secret' => ''

        )); 

  echo $args['before_widget'];
   
    if($instance['title']) {
      echo $args['before_title'].$instance['title'].$args['after_title'];
    }
    
    if($instance['twitter_username'] && trim($instance['consumer_key']) && trim($instance['consumer_secret']) && trim($instance['access_token']) && trim($instance['access_token_secret']) && $instance['count']) { 
    require_once 'twitteroauth/twitteroauth.php';
    $transName = 'list_tweets';
    $cacheTime = 1;
    if(false === ($twittermsg = get_transient($transName))) {
         // require the twitter auth class
         require_once 'twitteroauth/twitteroauth.php';
         $twitterConnection = new TwitterOAuth(
             trim($instance['consumer_key']),  // Consumer Key
              trim($instance['consumer_secret']),     // Consumer secret
              trim($instance['access_token']),       // Access token
              trim($instance['access_token_secret'])     // Access token secret
              );
         $twittermsg = $twitterConnection->get(
                'statuses/user_timeline',
                array(
                  'screen_name'     => $instance['twitter_username'],
                  'count'           => $instance['count'],
                  'exclude_replies' => true
                )
              );
         if($twitterConnection->http_code != 200)
         {
              $twittermsg = get_transient($transName);
         }
         // Save our new transient.
         set_transient($transName, $twittermsg, 60 * $cacheTime);
    }
    $twitter = get_transient($transName);
    if($twitter && is_array($twitter)) {
      //var_dump($twitter);
    ?>
    
          <div class="twitter_container" id="tweets_<?php echo $args['widget_id']; ?>">
            <ul>
              <?php foreach($twitter as $tweet): ?>
              <li><i class="fa fa-twitter"> </i>
                <span class="description">
                <?php
                $latestTweet = $tweet->text;
                $latestTweet = preg_replace('/http:\/\/([a-z0-9_\.\-\+\&\!\#\~\/\,]+)/i', '<a href="http://$1" target="_blank">http://$1</a>', $latestTweet);
                $latestTweet = preg_replace('/@([a-z0-9_]+)/i', '<a href="http://twitter.com/$1" target="_blank">@$1</a>', $latestTweet);
                echo $latestTweet;
                ?>
              
                <?php
                $twitterTime = strtotime($tweet->created_at);
                $timeAgo = $this->ago($twitterTime);
                ?>
                <a href="http://twitter.com/<?php echo $tweet->user->screen_name; ?>/statuses/<?php echo $tweet->id_str; ?>" ><?php echo $timeAgo; ?></a>
                </span>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
    <?php }}
    
    echo $args['after_widget'];
  }
  
  function ago($time)
  {
     $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
     $lengths = array("60","60","24","7","4.35","12","10");

     $now = time();

         $difference     = $now - $time;
         $tense         = "ago";

     for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
         $difference /= $lengths[$j];
     }

     $difference = round($difference);

     if($difference != 1) {
         $periods[$j].= "s";
     }

     return "$difference $periods[$j] ago ";
  }

 function form($instance)
  {

 $instance = wp_parse_args($instance, array(
          'title' => '',
          'twitter_username' => '', 
          'count' => 3, 
          'consumer_key' => '',
          'access_token' => '',
          'consumer_secret' => '', 
          'access_token' => '', 
          'access_token_secret' => ''

        )); 
?>
    
    <p>
      <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Twitter Title:',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('consumer_key'); ?>"><?php _e('Consumer Key:',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('consumer_key'); ?>" name="<?php echo $this->get_field_name('consumer_key'); ?>" value="<?php echo $instance['consumer_key']; ?>" />
    </p>
    
    <p>
      <label for="<?php echo $this->get_field_id('consumer_secret'); ?>"><?php _e('Consumer Secret:',cooks) ?></label>
      <input class="widefat" type="text"  id="<?php echo $this->get_field_id('consumer_secret'); ?>" name="<?php echo $this->get_field_name('consumer_secret'); ?>" value="<?php echo $instance['consumer_secret']; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('access_token'); ?>"><?php _e('Access Token:',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('access_token'); ?>" name="<?php echo $this->get_field_name('access_token'); ?>" value="<?php echo $instance['access_token']; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('access_token_secret'); ?>"><?php _e('Access Token Secret:',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('access_token_secret'); ?>" name="<?php echo $this->get_field_name('access_token_secret'); ?>" value="<?php echo $instance['access_token_secret']; ?>" />
    </p>
    
    <p>
      <label for="<?php echo $this->get_field_id('twitter_username'); ?>"><?php _e('Twitter User Name:',cooks) ?></label>
      <input class="widefat" type="text"  id="<?php echo $this->get_field_id('twitter_username'); ?>" name="<?php echo $this->get_field_name('twitter_username'); ?>" value="<?php echo $instance['twitter_username']; ?>" />
    <p>
      <label for="<?php echo $this->get_field_id('count') ?>"><?php _e('Number of Tweets:',cooks) ?></label>
      <input class="widefat" type="text" id="<?php echo $this->get_field_id('count') ?>" name="<?php echo $this->get_field_name('count') ?>" value="<?php echo esc_attr($instance['count']) ?>">    
    </p>
  <?php
  }
}
// Price List

 class cooks_Simple_Food_Menu_Widget extends WP_Widget{
   public function __construct(){
   parent::__construct(  'kaya-simple-food-menu',
      __('Cooks-Tabular Foodmenu (PB)',cooks),
      array( 'description' => __('Add food menu items with price in table format',cooks), 'class' => 'kaya_food_menu_widget' )
    );
    }
    public function widget( $args , $instance ){
        $instance = wp_parse_args($instance, array(
          'title' => __('Tabular Foodmenu Title',cooks),
          'title_color' => '',
          'list_box' => '',
          'text_align' => __('left',cooks),
          'items_list_box' => '
 <ul>&lt;br&gt;
<li><span>Food Item - 1</span><span>$20</span></li>&lt;br&gt;
<li><span>Food Item - 2</span><span>$10</span></li>&lt;br&gt;
<li><span>Food Item - 3</span><span>$40</span></li>&lt;br&gt;
</ul>',
           'items_list_box_text_color' => '#ffffff',
          'items_list_box_bg_color' => '#333',

             )); 
        $rand = rand(1,100);
             ?>
      <style type="text/css">
        .items_list_box<?php echo $rand; ?> ul li{
          color: <?php echo $instance['items_list_box_text_color']; ?>!important;
          background-color: <?php echo $instance['items_list_box_bg_color']; ?>!important;
        }
      </style>
  <?php echo $args['before_widget'];

   if( $instance['title'] ):

       echo '<div class="custom_title kaya_title_'.$instance['text_align'].'">';
         echo  '<h3 style="text-align:'.$instance['text_align'].'; color:'.$instance['title_color'].'!important;">'.$instance['title'].'</h3>';
      echo '</div>';
      ?>
  <div class="clear"> </div>
  <?php endif; 
         echo '<div class="items_list_box items_list_box'.$rand.'">';
            echo $instance['items_list_box'];
         echo '</div>';
         echo $args['after_widget'];
    }

    public function form( $instance ){

       $instance = wp_parse_args( $instance, array(
          'title' => __('Tabular Foodmenu Title',cooks),
          'title_color' => '#343434',
          'list_box' => '',
          'text_align' => __('left',cooks),
          'items_list_box_text_color' => '#ffffff',
          'items_list_box_bg_color' => '#333',
          'items_list_box' => __('<ul><li><span>Food Item - 1</span><span>$20</span></li><li><span>Food Item - 2</span><span>$10</span></li><li><span>Food Item - 3</span><span>$40</span></li></ul>',cooks),

        ) );
      ?>
      
        <p>
          <lable for="<?php echo $this->get_field_id('title'); ?>">
          <?php _e('Title',cooks); ?>
          </label>
          <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo $this->get_field_name('title') ?>" />
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('title_color'); ?>">
          <?php _e('Title Color',cooks) ?>
          </label>
          <input type="text" name="<?php echo $this->get_field_name('title_color') ?>" id="<?php echo $this->get_field_id('title_color') ?>" class="widefat" value="<?php echo $instance['title_color'] ?>" />
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('text_align') ?>"> <?php _e('Title Position',cooks)?> </label>
          <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('text_align') ?>">
            <option value="left" <?php selected('left', $instance['text_align']) ?>>
            <?php esc_html(_e(' Left',cooks)); ?>
            </option>
            <option value="right" <?php selected('right', $instance['text_align']) ?>>
            <?php esc_html(_e(' Right',cooks)); ?>
            </option>
            <option value="center" <?php selected('center', $instance['text_align']) ?>>
            <?php esc_html(_e(' Center',cooks)); ?>
            </option>
          </select>
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('items_list_box') ?>"> <?php _e('Menu Items List Box',cooks)?></label>
          <textarea type="text" id="<?php echo $this->get_field_id('items_list_box') ?>" class="widefat" name="<?php echo $this->get_field_name('items_list_box') ?>" value = "<?php echo esc_attr( $instance['items_list_box'] ) ?>" > <?php echo esc_attr( $instance['items_list_box'] ) ?></textarea>
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('items_list_box_bg_color'); ?>">
          <?php _e('Background Color',cooks) ?>
          </label>
          <input type="text" name="<?php echo $this->get_field_name('items_list_box_bg_color') ?>" id="<?php echo $this->get_field_id('items_list_box_bg_color') ?>" class="widefat" value="<?php echo $instance['items_list_box_bg_color'] ?>" />
        </p>
         <p>
          <label for="<?php echo $this->get_field_id('items_list_box_text_color'); ?>">
          <?php _e('Text Color',cooks) ?>
          </label>
          <input type="text" name="<?php echo $this->get_field_name('items_list_box_text_color') ?>" id="<?php echo $this->get_field_id('items_list_box_text_color') ?>" class="widefat" value="<?php echo $instance['items_list_box_text_color'] ?>" />
        </p>
<?php  }

 }
 /**
 *  Reservation Form
 */
 class cooks_Reservation_form extends WP_Widget
 {
  public function __construct(){
   parent::__construct( 'Cooks-reservation-form', 
      __('Cooks - Reservation Form', cooks),
      array(  'description' => __('Add Reservation form',cooks), 'class' => 'reservation_form'   ));
   }
   public function widget( $args , $instance ){

      $instance = wp_parse_args($instance , array(
            'button_text' => __('Mail Us',cooks),
            'clear_button_text' => __('Clear',cooks),
            'email_id' => __('yourdomain@gmail.com',cooks),
        ));
      echo $args['before_widget'];
         ?>
        <script type="text/javascript">
          jQuery(document).ready(function() {
            jQuery('.res_date').datepicker({
              dateFormat : 'dd-mm-yy'
            });
         });

        </script>
        <form method="post" action="sendEmail.php" name="contact-form" id="contact-form">

          <div id="main">
            <div id="response" />
          </div>
            <input type="hidden" name="res_email_id" id="res_email_id" value="<?php echo $instance['email_id']; ?>" />
            <p class="one_half"><input type="text" name="res_name" id="res_name" size="23"  placeholder="<?php _e('Name',cooks); ?>" /></p>
            <p class="one_half_last"><input type="text" name="res_email" placeholder="<?php _e('Email',cooks); ?>" id="res_email" size="23" /></p>
            <p class="one_third"> <input type="text" name="res_phone" id="res_phone" size="23"  placeholder="<?php _e('Phone',cooks); ?>"/></p>
            <p class="one_third"><input type="text" name="res_persons" id="res_persons" size="23"  placeholder="<?php _e('Number Of Persons',cooks); ?>" /></p>
            <p class="one_third_last"><input type="text" class="res_date" name="res_date" id="res_date"  placeholder="<?php _e('Reservation On',cooks); ?>" value=""/></p>
            <p class="one_third"><input type="text" name="res_time" placeholder="<?php _e('Time',cooks); ?>" id="res_time" size="23" /></p>
            <p class="two_third_last"><input type="text" name="res_subject" placeholder="<?php _e('Subject',cooks); ?>" id="res_subject" size="23" /></p>
            <p class="fullwidth"><textarea name="res_message" id="res_message" cols="30" rows="4" placeholder="<?php _e('Your Message',cooks); ?>"></textarea></p>
            <p style="padding-bottom:0"><input  class="readmore readmore-1 readmore-1a" type="submit" name="submit" id="submit" value="<?php echo $instance['button_text'] ?>" /> 
              <?php if(  $instance['clear_button_text'] ): ?>
                <input  class="readmore readmore-1 readmore-1a" type="reset" name="reset" id="reset" value="<?php echo $instance['clear_button_text'] ?>" />
              <?php endif; ?>
            </p>
        </div>
        </form>
      <?php echo $args['after_widget']; 
   }
   public function form( $instance ){
           $instance = wp_parse_args($instance , array(
            'button_text' => __('Mail Us',cooks),
            'clear_button_text' => __('Clear',cooks),
            'email_id' => __('yourdomain@gmail.com',cooks),
        ));
  ?>
  <p>
      <label for="<?php echo $this->get_field_id('email_id'); ?>"> <?php _e('Email Id',cooks) ?> </label>
      <input type="text" name="<?php echo $this->get_field_name('email_id') ?>" id="<?php echo $this->get_field_id('email_id') ?>" class="widefat" value="<?php echo $instance['email_id'] ?>" />
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('button_text'); ?>"> <?php _e('Submit Button Text',cooks) ?> </label>
      <input type="text" name="<?php echo $this->get_field_name('button_text') ?>" id="<?php echo $this->get_field_id('button_text') ?>" class="widefat" value="<?php echo $instance['button_text'] ?>" />
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('clear_button_text'); ?>"> <?php _e('Clear Button Text',cooks) ?> </label>
      <input type="text" name="<?php echo $this->get_field_name('clear_button_text') ?>" id="<?php echo $this->get_field_id('clear_button_text') ?>" class="widefat" value="<?php echo $instance['clear_button_text'] ?>" />
    </p>  
 <?php }
  }
 /**
 *  Reservation Form
 */
 class cooks_Contact_Form extends WP_Widget
 {
  public function __construct(){
   parent::__construct( 'Cooks-contact-form', 
      __('Cooks - Contact Form', cooks),
      array(  'description' => __('Add Contact form',cooks), 'class' => 'contact_form'   ));
   }
   public function widget( $args , $instance ){

      $instance = wp_parse_args($instance , array(
            'button_text' => __('Mail Us',cooks),
            'clear_button_text' => __('Clear',cooks),
            'email_id' => __('yourdomain@gmail.com',cooks),
        ));
      echo $args['before_widget']; 
      ?>
        <form method="post" action="sendEmail.php" name="contact-form" id="contact-form">
          <div id="main">
            <div id="contact_response" />
          </div>
          <input type="hidden" name="siteemail" id="siteemail" value="<?php echo $instance['email_id']; ?>" />
          <p class="one_third"><input type="text" name="name" id="name" size="23"   placeholder="<?php _e('Name',cooks); ?>"  /></p>
          <p class="one_third"><input type="text" name="email" placeholder="<?php _e('Email',cooks); ?>" id="email" size="23" /></p>
          <p class="one_third_last"><input type="text" name="subject" placeholder="<?php _e('Subject',cooks); ?>" id="subject" size="23" /></p>
          <p class="fullwidth"><textarea name="message" id="message" cols="30" rows="4" placeholder="<?php _e('Message',cooks); ?>"></textarea></p>
          <p style="padding-bottom:0"><input  class="readmore readmore-1 readmore-1a" type="submit" name="contact_submit" id="contact_submit" value="<?php echo $instance['button_text'] ?>" /> 
          <?php if( $instance['clear_button_text'] ): ?>  
            <input  class="readmore readmore-1 readmore-1a" type="reset" name="reset" id="reset" value="<?php echo $instance['clear_button_text'] ?>" /></p>
          <?php endif; ?>
          </div>
        </form>
      <?php echo $args['after_widget']; 
   }
   public function form( $instance ){
           $instance = wp_parse_args($instance , array(
            'button_text' => __('Mail Us',cooks),
            'clear_button_text' => __('Clear',cooks),
            'email_id' => __('yourdomain@gmail.com',cooks),
        ));
  ?>
   <p>
      <label for="<?php echo $this->get_field_id('email_id'); ?>"> <?php _e('Email Id',cooks) ?> </label>
      <input type="text" name="<?php echo $this->get_field_name('email_id') ?>" id="<?php echo $this->get_field_id('email_id') ?>" class="widefat" value="<?php echo $instance['email_id'] ?>" />
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('button_text'); ?>"> <?php _e('Submit Button Text',cooks) ?> </label>
      <input type="text" name="<?php echo $this->get_field_name('button_text') ?>" id="<?php echo $this->get_field_id('button_text') ?>" class="widefat" value="<?php echo $instance['button_text'] ?>" />
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('clear_button_text'); ?>"> <?php _e('Clear Button Text',cooks) ?> </label>
      <input type="text" name="<?php echo $this->get_field_name('clear_button_text') ?>" id="<?php echo $this->get_field_id('clear_button_text') ?>" class="widefat" value="<?php echo $instance['clear_button_text'] ?>" />
    </p>  
 <?php }
  }
  // Restaurant Menu Items

 class cooks_Restaurant_Menu_Widget extends WP_Widget{
    public function __construct(){
        parent::__construct('kaya-portfolio-widget',
            __('Cooks-CPT Food Menu (PB)',cooks),
            array('description' => __('Displays all portfolio items in grid style',cooks), 'class' => 'menu_items_widget')
        );
    }

    public function widget( $args, $instance ) {
      //echo $args['before_widget'];
          global $post;
      $instance=wp_parse_args($instance, array(

          'title' => __('Food Menu Title',cooks),
          'description' => '',
          'text_align'   => __('left',cooks),
          'title_color' => '#343434',
          'food_menu_widget_category' => '',
          'disable_title' => '',
          'Popular_post_display' => '',
          'menu_display_orderby' => __('Menu Order',cooks),
          'menu_display_order' => __('DESC',cooks),
          'hide_post_link_icon' => '',
          'hide_lightbox_icon' => '',
          'hide_post_title' => '',
          'hide_post_description' => '',
          'menu_item_title_color' => '#333',
          'menu_item_description_color' => '#787878',
          'description_color' => '#787878',
          'menu_limit' => '50',
          'disable_menu_item_img' => '',
          'menu_item_description_limt' => '10',
          'thumb_width' => '150',
          'thumb_height' => '100',
          'hide_price' => '',
          'disable_pagination' => '',

      )); ?>
<?php   $items = rand(1,200);
        $post_icon = ( $instance['hide_lightbox_icon'] == 'on' ) ? "50%" : '30%'; ?>
        <?php $post_class = ( $instance['hide_lightbox_icon'] == 'on' ) ? "left" : 'right'; ?>
        <?php $lightbox_icon = ( $instance['hide_post_link_icon'] == 'on' ) ? "50%" : '30%'; ?>
    <script type="text/javascript">
      (function($) {
        "use strict";
        $(function() {
            // Hover Effects
        $('.food-menu-items-<?php echo $items; ?> .item_container').hover(function(){
          $(this).find('img').fadeTo(500,0.6);
          $(this).find('.link_to_image, .link_to_video').css({'left':'-50px','display':'block'}).stop().animate({'left':'<?php echo $lightbox_icon; ?>', opacity:1},600);
          $(this).find('.link_to_post').css({'<?php echo $post_class; ?>':'-50px','display':'block'}).stop().animate({'<?php echo $post_class; ?>':'<?php echo $post_icon; ?>',opacity:1},600);
          //alert('test');
        },function(){
          $(this).find('img').fadeTo(500,1);
          $(this).find('.link_to_image, .link_to_video').css({'left':'50','display':'block'}).stop().animate({'left':'-<?php echo $lightbox_icon; ?>',opacity:0},600);
          $(this).find('.link_to_post').css({'<?php echo $post_class; ?>':'50px','display':'block'}).stop().animate({'<?php echo $post_class; ?>':'-<?php echo $post_icon; ?>',opacity:0},600);
       }); 

         });

      })(jQuery);
     </script>
    <?php 
        // $title = apply_filters('widget_title' ,$title);
         if( $instance['title'] ):
            echo '<div class="custom_title kaya_title_'.$instance['text_align'].'">';
             echo  '<h3 style="text-align:'.$instance['text_align'].'; color:'.$instance['title_color'].'!important;">'.$instance['title'].'</h3>';
             echo '</div>';
             ?>
            <div class="clear"> </div>
            <?php endif; ?>
          <div class="food_menu_wrapper">
            <ul class="food-menu-items-<?php echo $items; ?>">
            <?php  
            $array_val = ( !empty( $instance['food_menu_widget_category'] )) ? explode(',',  $instance['food_menu_widget_category']) : '';
            $food_pages = (get_query_var('paged')) ? get_query_var('paged') : 1;  
          if( $array_val ) {
          $args = array( 'paged' => $food_pages, 'post_type' => 'portfolio', 'orderby' => $instance['menu_display_orderby'], 'posts_per_page' =>$instance['menu_limit'],'order' => $instance['menu_display_order'], 'tax_query' => array('relation' => 'AND', array( 'taxonomy' => 'portfolio_category',   'field' => 'id', 'terms' => $array_val  ) ));
          }else{
             $args = array('paged' => $food_pages, 'post_type' => 'portfolio', 'taxonomy' => 'portfolio_category','term' => $instance['food_menu_widget_category'], 'orderby' => $instance['menu_display_orderby'], 'posts_per_page' =>$instance['menu_limit'],'order' => $instance['menu_display_order']);
          }    
          query_posts($args);

      if( have_posts() ) : while(have_posts() ) : the_post();
      $terms = get_the_terms(get_the_ID(), 'portfolio_category');
     $img_url=wp_get_attachment_url( get_post_thumbnail_id() );
         $pf_link_new_window=get_post_meta(get_the_ID(),'pf_link_new_window' ,true);
            if($pf_link_new_window == '1') { $pf_target_link ="_blank"; }else{ $pf_target_link ='_self'; }
          $lightbox_url =  get_template_directory_uri().'/images/defult_featured_img.png';
         $featured_img = $img_url ? $img_url : $lightbox_url;
        $permalink = get_permalink();
        $Porfolio_customlink=get_post_meta($post->ID,'Porfolio_customlink',true);
        $pf_customlink = $Porfolio_customlink ? $Porfolio_customlink : $permalink;
         $video_url= get_post_meta($post->ID,'video_url',true);
           $lightbox_type = $video_url ? trim($video_url) : $featured_img;
           $class = $video_url ? 'link_to_video' : 'link_to_image';
        $terms_slug = array();
        $terms_name = array();
        if($terms ){
        foreach ($terms as $term) {
          $terms_slug[] = $term->slug;
          $terms_name[] = $term ->name;
        }
      }else{
        $terms_name[] = 'Uncategorized';
      }
        echo '<li>';   
         if( $instance['disable_menu_item_img'] != 'on' ): ?>
        <div class="item_container alignleft">
            <?php $img_url = wp_get_attachment_url( get_post_thumbnail_id() );
            if( $img_url ) {
                $lightbox_url =  $img_url;
              echo '<img src="'.aq_resize( $img_url, $instance['thumb_width'], $instance['thumb_height'], true ).'" alt="'.get_the_title().'" />';
              }else{
                 $lightbox_url =  get_template_directory_uri().'/images/defult_featured_img.png';
                 echo '<img src="'.get_template_directory_uri().'/images/defult_featured_img.png" alt="'.get_the_title().'" style="width:'.$instance['thumb_width'].'px; height:'.$instance['thumb_height'].'px;">';
              }
               //echo '<span class="item_price">'.get_post_meta(get_the_ID(),'fooditem_price',true).'</span>'; ?>
                <?php if( $instance['hide_lightbox_icon'] != '1' && $instance['hide_lightbox_icon'] != 'on' ): ?>
                <a class="<?php echo $class; ?> pf_images" rel="prettyPhoto" href="<?php echo $lightbox_type; ?>">&nbsp;</a>
              <?php endif; ?>
              <?php if( $instance['hide_post_link_icon'] != '1' && $instance['hide_post_link_icon'] != 'on' ): ?>
                      <a class="link_to_post" target="<?php echo $pf_target_link; ?>" href="<?php echo $pf_customlink; ?>">&nbsp; </a>
              <?php endif; ?>
          </div> 
        <?php endif; ?>
       <div class="description food_menu_title">
        <?php if( $instance['hide_post_title'] != 'on' ): ?> <?php echo '<h4 style="color:'.$instance['menu_item_title_color'].';">'.get_the_title().'</h4>'; endif; ?>
        <?php if( $instance['hide_price'] != 'on' ):  echo '<span class="menu_item_price">'.get_post_meta(get_the_ID(),'fooditem_price',true).'</span>'; endif;?>
        <div class="clear"> </div>
        <?php if( $instance['hide_post_description'] != 'on' ): ?> <?php echo '<p style="color:'.$instance['menu_item_description_color'].'">'.strip_tags( cooks_content($instance['menu_item_description_limt']) ).'</p>'; endif; ?>
       </div> 
    </li>
       <?php endwhile; endif;   ?>
    </ul>
      <?php 
      if($instance['disable_pagination'] != 'on'){ 
        echo kaya_pagination(); 
      }
      ?>
     
    </div>
    <?php   //echo $args['after_widget'];
     wp_reset_query(); 
    }

    public function form($instance){

      $food_terms=  get_terms('portfolio_category','');
    if( $food_terms ){
      foreach ($food_terms as $food_term) { 
         $food_cats_name[] = $food_term->name.' - '.$food_term->term_id;
         $food_cats_id[] = $food_term->term_id;
      }
    }else{
      $food_cats_name[] = '';
      $food_cats_id[] = '';
    }

     
         $instance = wp_parse_args($instance, array(
          'title' => __('Food Menu Title',cooks),
          'description' => '',
          'text_align'   => __('left',cooks),
          'title_color' => '#343434',
          'food_menu_widget_category' => implode(',', $food_cats_id),
          'disable_title' => '',
          'Popular_post_display' => '',
          'menu_display_orderby' => __('menu_order',cooks),
          'menu_display_order' => __('DESC',cooks),
          'hide_post_link_icon' => '',
          'hide_lightbox_icon' => '',
          'hide_post_title' => '',
          'hide_post_description' => '',
          'menu_item_title_color' => '#333',
          'menu_item_description_color' => '#787878',
          'description_color' => '#787878',
          'menu_limit' => '50',
          'disable_menu_item_img' => '',
          'menu_item_description_limt' => '12',
          'thumb_width' => '150',
          'thumb_height' => '100',
          'hide_price' => '',
          'disable_pagination' => '',

      )); ?>
<p>
  <lable for="<?php echo $this->get_field_id('title'); ?>">
  <?php _e('Title',cooks); ?>
  </label>
  <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo $this->get_field_name('title') ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('title_color'); ?>">
  <?php _e('Title Color',cooks) ?>
  </label>
  <input type="text" name="<?php echo $this->get_field_name('title_color') ?>" id="<?php echo $this->get_field_id('title_color') ?>" class="widefat" value="<?php echo $instance['title_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('text_align') ?>">
  <?php _e('Title Position',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('text_align') ?>" name="<?php echo $this->get_field_name('text_align') ?>">
    <option value="left" <?php selected('left', $instance['text_align']) ?>>
    <?php esc_html(_e('Left',cooks)); ?>
    </option>
    <option value="right" <?php selected('right', $instance['text_align']) ?>>
    <?php esc_html(_e(' Right',cooks)); ?>
    </option>
    <option value="center" <?php selected('center', $instance['text_align']) ?>>
    <?php esc_html(_e(' Center',cooks)); ?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('food_menu_widget_category') ?>">  <?php _e('Enter Food Menu Category IDs : ',cooks) ?>  </label>
      <input type="text" name="<?php echo $this->get_field_name('food_menu_widget_category') ?>" id="<?php echo $this->get_field_id('food_menu_widget_category') ?>" class="widefat" value="<?php echo $instance['food_menu_widget_category'] ?>" />
<em><strong style="color:green;"><?php _e('Available Categories and IDs : ',cooks); ?> </strong> <?php echo implode(',', $food_cats_name); ?></em><br />
   <stong><?php _e('Note:',cooks); ?></strong><?php _e('Separate IDs with commas only',cooks); ?>
    </p>
<p>
  <label for="<?php echo $this->get_field_id('menu_display_orderby') ?>">  <?php _e('Orderby',cooks) ?>  </label>
  <select id="<?php echo $this->get_field_id('menu_display_orderby') ?>" name="<?php echo $this->get_field_name('menu_display_orderby') ?>">
    <option value="date" <?php selected('date', $instance['menu_display_orderby']) ?>>
    <?php esc_html(_e('Date',cooks) );?>
    </option>
    <option value="menu_order" <?php selected('menu_order', $instance['menu_display_orderby']) ?>>
    <?php esc_html(_e('Menu Order',cooks) );?>
    </option>
    <option value="title" <?php selected('title', $instance['menu_display_orderby']) ?>>
    <?php esc_html(_e('Title',cooks) );?>
    </option>
    <option value="rand" <?php selected('rand', $instance['menu_display_orderby']) ?>>
    <?php esc_html(_e('Random',cooks)); ?>
    </option>
    <option value="author" <?php selected('author', $instance['menu_display_orderby']) ?>>
    <?php esc_html(_e('Author',cooks) );?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('menu_display_order') ?>">
  <?php _e('Order',cooks)?>
  </label>
  <select id="<?php echo $this->get_field_id('menu_display_order') ?>" name="<?php echo $this->get_field_name('menu_display_order') ?>">
    <option value="ASC" <?php selected('ASC', $instance['menu_display_order']) ?>>
    <?php esc_html(_e('Ascending',cooks) );?>
    </option>
    <option value="DESC" <?php selected('DESC', $instance['menu_display_order']) ?>>
    <?php esc_html(_e('Descending',cooks)); ?>
    </option>
  </select>
</p>
<p>
  <label for="<?php echo $this->get_field_id('thumb_width'); ?>"><?php _e('Item Thumbnail Width(px)',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('thumb_width') ?>" id="<?php echo $this->get_field_id('thumb_width') ?>" class="widefat" value="<?php echo $instance['thumb_width'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('thumb_height'); ?>"><?php _e('Item Thumbnail Height(px)',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('thumb_height') ?>" id="<?php echo $this->get_field_id('thumb_height') ?>" class="widefat" value="<?php echo $instance['thumb_height'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('menu_item_title_color'); ?>"><?php _e('Item Title Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('menu_item_title_color') ?>" id="<?php echo $this->get_field_id('menu_item_title_color') ?>" class="widefat" value="<?php echo $instance['menu_item_title_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('menu_item_description_color'); ?>"><?php _e('Item Description Color',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('menu_item_description_color') ?>" id="<?php echo $this->get_field_id('menu_item_description_color') ?>" class="widefat" value="<?php echo $instance['menu_item_description_color'] ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('menu_item_description_limt'); ?>"><?php _e('Item Description Limit',cooks) ?></label>
  <input type="text" name="<?php echo $this->get_field_name('menu_item_description_limt') ?>" id="<?php echo $this->get_field_id('menu_item_description_limt') ?>" class="widefat" value="<?php echo $instance['menu_item_description_limt'] ?>" />
</p>
    <p>
  <label for="<?php echo $this->get_field_id('disable_menu_item_img') ?>"><?php _e('Disable Item Image',cooks)?></label>&nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_menu_item_img"); ?>" name="<?php echo $this->get_field_name("disable_menu_item_img"); ?>"<?php checked( (bool) $instance["disable_menu_item_img"], true ); ?> />
  </p>
  <p>
  <label for="<?php echo $this->get_field_id('hide_lightbox_icon') ?>"><?php _e('Disable Lightbox icon',cooks)?></label>&nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_lightbox_icon"); ?>" name="<?php echo $this->get_field_name("hide_lightbox_icon"); ?>"<?php checked( (bool) $instance["hide_lightbox_icon"], true ); ?> />
  </p>
  <p>
  <label for="<?php echo $this->get_field_id('hide_post_link_icon') ?>"><?php _e('Disable Link icon',cooks)?></label>&nbsp;
  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_post_link_icon"); ?>" name="<?php echo $this->get_field_name("hide_post_link_icon"); ?>"<?php checked( (bool) $instance["hide_post_link_icon"], true ); ?> />
  </p>
  <p>
    <label for="<?php echo $this->get_field_id('hide_post_title') ?>"><?php _e('Disable Item Title',cooks)?></label>&nbsp;
   <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_post_title"); ?>" name="<?php echo $this->get_field_name("hide_post_title"); ?>"<?php checked( (bool) $instance["hide_post_title"], true ); ?> />
  </p>
   <p>
        <label for="<?php echo $this->get_field_id('hide_price') ?>"><?php _e('Disable Price',cooks)?></label>&nbsp;
       <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_price"); ?>" name="<?php echo $this->get_field_name("hide_price"); ?>"<?php checked( (bool) $instance["hide_price"], true ); ?> />
      </p>
    <p>
    <label for="<?php echo $this->get_field_id('hide_post_description') ?>"><?php _e('Disable Item Description',cooks)?></label>&nbsp;
   <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("hide_post_description"); ?>" name="<?php echo $this->get_field_name("hide_post_description"); ?>"<?php checked( (bool) $instance["hide_post_description"], true ); ?> />
  </p>
  <p>
  <label for="<?php echo $this->get_field_id('menu_limit') ?>">
  <?php _e('Items Limit',cooks)?>
  </label>
  <input type="text" class="widefat" id="<?php echo $this->get_field_id('menu_limit') ?>" value="<?php echo esc_attr($instance['menu_limit']) ?>" name="<?php echo $this->get_field_name('menu_limit') ?>" />
</p>
<p>
    <label for="<?php echo $this->get_field_id('disable_pagination') ?>"><?php _e('Disable Pagination',cooks)?></label>&nbsp;
   <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_pagination"); ?>" name="<?php echo $this->get_field_name("disable_pagination"); ?>"<?php checked( (bool) $instance["disable_pagination"], true ); ?> />
  </p>
<?php

}

 }
// Limit Content
function cooks_content($limit) {
    $content = explode(' ', get_the_content(), $limit);
    if (count($content)>=$limit) {
    array_pop($content);
    $content = implode(" ",$content).' ';
    } else {
    $content = implode(" ",$content);
    }   
    $content = preg_replace('/\[.+\]/','', $content);
    $content = apply_filters('get_the_content', $content);
    $content = str_replace(']]>', ']]&gt;', $content);
    return $content;
}

// Widget Registration

function kaya_cooks_widgets(){

    register_widget('cooks_Portfolio_Widget');
    register_widget('cooks_Title_Widget');
    register_widget('cooks_vspace_Widget');
    register_widget('cooks_Slider_Widget');
    register_widget('cooks_Dropcap_Widget');
    register_widget('cooks_Draggable_slider_Widget');
    register_widget('cooks_Imageboxes_Widget');
    register_widget('cooks_Info_Boxes');
    register_widget('cooks_Custom_List_Box_Widget');
    register_widget('cooks_Flickr_Widget');
    register_widget('cooks_Recent_Blog_Widget');
    register_widget('cooks_Readmore_Button_Widget');
    register_widget('cooks_Reservation_form');
    register_widget('cooks_Testimonial_Widget');
    register_widget('cooks_Toggle_Tabs_Accordion');
    register_widget('cooks_Pricing_Table');
    register_widget('cooks_Twitter_Widget');
    register_widget('cooks_Simple_Food_Menu_Widget');
    register_widget('cooks_Contact_Form');
    register_widget('cooks_Restaurant_Menu_Widget');
}

add_action( 'widgets_init', 'kaya_cooks_widgets');



function kaya_cooks_widgets_styles()

{

  //wp_enqueue_script( 'jquery' );

      wp_register_style('css_cooks_page_widgets', plugins_url('css/page_widgets.css', __FILE__));
      wp_register_style('css_widget_bxslider', plugins_url('css/widget_bxslider.css', __FILE__));
      wp_register_style('css_owl.carousel', plugins_url('css/owl.carousel.css', __FILE__));
      wp_enqueue_style('css_cooks_page_widgets');
      wp_enqueue_style('css_widget_bxslider');
      wp_enqueue_style('css_font-awesome');
      wp_enqueue_style('css_owl.carousel');
      wp_enqueue_script('jquery_bxslider');
      wp_enqueue_style('css_bxslider');
      wp_enqueue_script('jquery-ui-datepicker');

}

function kaya_cooks_widgets_scripts(){

    wp_register_script('widget_jquery_bxslider', plugins_url('js/jquery.bxslider.js', __FILE__),array( 'jquery' ),'', true);
    wp_register_script('js_owl.carousel', plugins_url('js/owl.carousel.js', __FILE__),array( 'jquery' ),'1.29', true);
    wp_register_script('cooks_js_widget_contact', plugins_url('js/widget_contact.js', __FILE__),array( 'jquery' ),'', true);
    wp_register_script('cooks_js_scripts', plugins_url('js/scripts.js', __FILE__),array( 'jquery' ),'', true);
    wp_localize_script( 'jquery', 'cpath', array('plugin_dir' => plugins_url('',__FILE__)));

    wp_enqueue_script('widget_jquery_bxslider');
    wp_enqueue_script('js_owl.carousel');
    wp_enqueue_script('sap_js_scripts');
    wp_enqueue_script('jquery-ui-accordion');
    wp_enqueue_script('jquery-ui-tabs');
    wp_enqueue_script('cooks_js_widget_contact');
    wp_enqueue_script('cooks_js_scripts');

}

include( plugin_dir_path( __FILE__ ) . 'aq_resizer.php');
add_action('wp_enqueue_scripts', 'kaya_cooks_widgets_styles'); // styles files
add_action('wp_enqueue_scripts', 'kaya_cooks_widgets_scripts'); //script files

add_action('admin_head', 'kaya_cooks_admin_script'); //script files
function kaya_cooks_admin_script(){
  wp_enqueue_media();
 }
// Language 
class Cooks_Language_Translation{
  public function __construct(){
     add_action('plugins_loaded', array(&$this,'cooks_plugin_textdomain'));
  }
    public  function cooks_plugin_textdomain() {
    $domain = 'kaya-cooks-page-widgets';
      $locale = apply_filters( 'plugin_locale', get_locale(), $domain );
      load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' );
      load_plugin_textdomain( $domain, FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
        }
}
$language_file = new Cooks_Language_Translation();
?>
