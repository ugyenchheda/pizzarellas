(function( $ ) {
    "use strict";
    $(function() {
    	// Info Boxes
  $( ".info_box .delete" ).click(function() {
        $(this).parent('.info_box').parent().animate({ opacity: 'hide' }, "slow");
    });
  $(".toggle_content").hide();
           $("strong.trigger").click(function(){
         $(this).toggleClass("active").next().slideToggle("slow");
      
    });
   
  function fluid_script(){
   var $content_width= $('#fluid_layout .widget_kaya-promobox, #fluid_layout .promobox-video > div').width($(window).width());
		var $container_fluid = Math.ceil( (($(window).width()  - parseInt($('.container').css('width'))) / 2) );
		$(' #fluid_layout .widget_kaya-promobox').css({
		   'margin-left' : -$container_fluid,
		   width : $content_width+'25'
		});
		var $vals = $('#box_layout').css('width');
		$('#box_layout .widget_kaya-promobox, #box_layout .promobox-video > div').css({
		   'width' : $vals,
		});
		$('#box_layout .widget_kaya-promobox').css({
		   'margin-left' : -30,
		   		});
		//alert();
		$('.widget_kaya-promobox').css({
		   'position' : 'absolute',
		   'top' : 0,
		   'overflow' : 'hidden',
		   'height' : '100%',
		  });
        }

 fluid_script();
   $(window).resize(function(){
	  fluid_script();
	});

});
})(jQuery);
